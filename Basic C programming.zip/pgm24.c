/*Program to input three number and find there sum and average using separate function*/
#include<stdio.h>
int sum(int a,int b,int c);
float average(float x);

void main()
{
int n1,n2,n3,total;
float avg;
printf("Enter the number:\n");
scanf("%d %d %d",&n1,&n2,&n3);
total=sum(n1,n2,n3);
printf("The sum of the number is : %d",total);
avg=average(total);
printf("\nThe average of the number is:%f\n",avg);
}

int sum(int a,int b,int c){
int total=0;
total=a+b+c;
return total;
}

float average(float x){
float avg=0;
avg=x/3;
return avg;
}
