//Program to find the fabonacci series in a array 10//

#include<stdio.h>
void main()
{
	int no[10],a;
	no[0]=0;
	no[1]=1;
	for(a=2;a<10;a++)
	{
	no[a]=no[a-1]+no[a-2];
	printf("%d\n",no[a]);
	}
}
