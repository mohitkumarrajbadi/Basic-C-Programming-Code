/*Program to swapt number using the funtion*/
#include<stdio.h>
int swap(int a,int b);
void main()
{
int num1,num2,sp;
printf("Enter two number :\n");
scanf("%d %d",&num1,&num2);
printf("After reverse a=%d and b=%d\n",num1,num2);
swap(num1,num2);
}


int swap(int a,int b){
int num,c;
c=a+b;
a=c-a;
b=c-a;
printf("After reverse a=%d and b=%d\n",a,b);
}
