//Program to print the greatest of the 10 numbers//

#include<stdio.h>
void main()
{
	int a[10];
	int i;
	int greatest;
	printf("Enter 10 number to check the greatest one:\n");
	for(i=0;i<=10;i++)
	{
		scanf("%d",&a[i]);
	}
	greatest=a[0];
	for(i=0;i<=10;i++)
		{
		if(a[i]>greatest)
		{
		greatest=a[i];
		}
		}
printf("Greatest of ten number in %d",greatest);
}
