/*Program to check whether the number is palindrome or not using function*/

#include<stdio.h>
int palindrome(int a,int b);
void main()
{
int num,a,n,rev;
printf("Enter the number:");
scanf("%d",&num);
a=num;
while(a!=0)
	{
	a=a/10;
	n++;
	}
rev=palindrome(num,n);

if(rev == num)
	{
	printf("\nThe number is Armstrong number\n");
	}
	else
	{
	printf("\nThe number is not a Armstrong number\n");
	}
}


int palindrome(int a,int b){
		int power,sum=0,rem;
		while(a!=0)
			{
			rem=a%10;
			power=pow(rem,b);
			sum=sum+power;
			a=a/10;
			}
return sum;
}
