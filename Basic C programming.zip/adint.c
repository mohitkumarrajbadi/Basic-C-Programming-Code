//Program to reverse a integer//
#include<stdio.h>
void main()
{
int num,temp,reminder,reverse=0;
printf("Enter an integer\n");
scanf("%d",&num);
temp=num;
while(num>0)
{
reminder=num%10;reverse=reverse*10+reminder;
num/=10;
}
printf("The reverse number is:%d\n",reverse);
}
