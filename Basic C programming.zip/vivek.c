#include<stdio.h>
void main()
{
	char a;
	scanf("%c",&a);
	if(a=='v')
	printf("Vivek is a good boy\n");
	else
	printf("Vivek is a bad boy\n");
}
