/*Program to generate pattern

*****
 ***
  *

*/

#include<stdio.h>
void main()
{
int i,j,a;
for(i=0;i<3;i++)
{
for(j=0;j<i;j++)
	printf(" ");	
for(a=0;a<5-2*i;a++)
	{
	printf("*");
	}
printf("\n");
}

}
