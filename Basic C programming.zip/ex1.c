/*Print the element of the matrix in spiral form*/
#include<stdio.h>
void main()
{
int rows,cols;
printf("Enter the number of rows: ");
scanf("%d",&rows);
printf("Enter the number of colons: ");
scanf("%d",&cols);

int a[rows][cols],i,j;
for(i=0;i<rows;i++)
	for(j=0;j<cols;j++)
	if((i>0 && i<rows-1 && j>0 && j<cols-1) || (i>j)){}
	else
	{
		scanf("%d",&a[i][j]);	
		}

printf("\n\n\n");

for(i=0;i<rows;i++){
	for(j=0;j<cols;j++)
	{
	printf("%d\t",a[i][j]);	
	}
	printf("\n");
	}

printf("\n");
printf("\n");
printf("\n");
for(i=0;i<rows;i++){
	for(j=0;j<cols;j++){
		
		}
	printf("\n");
	}
}
