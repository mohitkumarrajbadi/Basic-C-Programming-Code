/*Program to input number and find the factorial of the number*/
#include<stdio.h>
int fact(int a);
void main()
{
int num,factorial;
printf("Enter the number :");
scanf("%d",&num);
factorial=fact(num);
printf("\nThe factorial of the number %d is: %d \n",num,factorial);
}

int fact(int a){
int facto=1,i;
for(i=1;i<=a;i++)
	{
	facto=facto*i;
	}
return facto;
}
