/*Program for Bank Operation*/

#include<stdio.h>
int deposit(float a);
int withdrawal(float b);
void main()
{
char consumername[50],ch;
long consumernumber;
int balance,y=1;
float intialdeposit,with,depos;

printf("ENTER THE CONSUMER NAME:\n");
gets(consumername);
printf("ENTER THE CONSUMER NUMBER:\n");
scanf("%ld",&consumernumber);
printf("Enter your initial deposit:\n");
scanf("%f",&intialdeposit);
depos=intialdeposit;

while(y==1)
{
printf("Enter the (D=Deposit W=Withdrawal):");
scanf(" %c",&ch);

	switch(ch)
	{
	case 'D':depos=deposit(depos);
		printf("\nBalance:%f\n",depos);
		break;
	case 'W':
		with=withdrawal(depos);
		depos=with;
		printf("\nBalance:%f\n",with);
		break;
	case 'd':
		depos=deposit(depos);
		printf("\nBalance:%f\n",depos);			
		break;
	case 'w':
		with=withdrawal(depos);
		depos=with;
		printf("\nBalance:%f\n",with);
		break;
	}
	printf("Press to continue 1(yes) or 2(no) or 3(balance)");
	scanf("%d",&y);
		if(y==3)
		{
		printf("\nBalance=%f\n",depos);
		}
	}	
}
int deposit(float a){
		float amount,balance;
		printf("\nEnter the amount\n");
		scanf("%f",&amount);
		balance=a+amount;
		return balance;
		}
int withdrawal(float b){
		float amount,balance;
		printf("\nEnter the amount\n");
		scanf("%f",&amount);
		if(amount<b)
			balance=b-amount;
		else
			printf("\nNo sufficient balance!!!!Enter amount less than balance;\n");
			return balance;
}
