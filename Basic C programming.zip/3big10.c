//PRINT 3(I.E. 1ST BIG,2ND BIG AND 3RD BIG) BIGGEST NUMBER AMONG THE 10//

#include<stdio.h>
void main()
{
	int a,b,c,n,i=1;
	printf("Enter a number:\n");
	scanf("%d",&n);
	a=b=c=n;
	while(i<10)
	{
		printf("Enter a Number:\n");
		scanf("%d",&n);
		if(n>a)
		{
			c=b;b=a;a=n;
		}	
		else if (n>b)
		{
		c=b;b=n;
		}
		else
		{
		if(a==b)
		b=c=n;
		if(n>c)
		c=n;
		}
		i++;
	}
printf("The biggest three numbers are %d %d %d",a,b,c);
}
