//Printing number as 1 2 3 4 5 /n 6 7 8 9 10....25
#include <stdio.h>
void main()
{
	int a,b;
	for(a=1;a<=1;a++)
	{
	for(b=1;b<=25;b++)
	{
	printf("%d\t",b);
	if (b%5==0)
	printf("\n");	
	}
}
}
