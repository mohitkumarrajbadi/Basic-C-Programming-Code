/*Program to input size and create a identity matrix*/

#include<stdio.h>
void identity(int a);
void main()
{
int x;
printf("Enter the number:");
scanf("%d",&x);
identity(x);
}

void identity(int a){
int arry[a][a],i,j;
for(i=0;i<a;i++){
	for(j=0;j<a;j++){
		if(i==j)
		arry[i][j]=1;	
		else		
		arry[i][j]=0;	
		}
	}

for(i=0;i<a;i++){
	for(j=0;j<a;j++){
		printf("%d\t",arry[i][j]);	
		}
	printf("\n");
	}
}
