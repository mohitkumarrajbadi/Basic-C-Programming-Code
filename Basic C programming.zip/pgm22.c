/*Program to perform addition,substraction,multiplication&division of two number using function*/

#include<stdio.h>
void addition();
void substraction();
void multiplication();
void division();

void main()
{
char ch;
printf("Enter the character you want to perform:");
scanf("%c",&ch);
	if(ch=='+')
	{
	addition();
	}
	else if(ch=='-')
	{
	substraction();
	}
	else if(ch=='*')
	{
	multiplication();
	}
	else if(ch=='/')
	{
	division();
	}
}

void addition()
{
	int c;
	int num1,num2;
	printf("Enter the 1st number:");
	scanf("%d",&num1);
	printf("Enter the 2st number:");
	scanf("%d",&num2);
	c = num1 + num2;
	printf("=%d\n",c);
}

void substraction()
{
	int c;
	int num1,num2;
	printf("Enter the 1st number:");
	scanf("%d",&num1);
	printf("Enter the 2st number:");
	scanf("%d",&num2);
	c = num1 - num2;
	printf("=%d\n",c);
}

void multiplication()
{
	int c;
	int num1,num2;
	printf("Enter the 1st number:");
	scanf("%d",&num1);
	printf("Enter the 2st number:");
	scanf("%d",&num2);
	c = num1 * num2;
	printf("=%d\n",c);
}

void division()
{
	float c;
	float num1,num2;
	printf("Enter the 1st number:");
	scanf("%f",&num1);
	printf("Enter the 2st number:");
	scanf("%f",&num2);
	c = num1 / num2;
	printf("=%f\n",c);
}
