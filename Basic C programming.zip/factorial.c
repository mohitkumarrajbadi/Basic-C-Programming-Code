#include<stdio.h>
void main()
{
	int no,fact=1;
	printf("Enter an integer:\n");
	scanf("%d"&no);
	while(no)
	{
		fact*=no--;
	}
printf("Factorial is %d:\n",fact);
}
