#include<stdio.h>
void main()
{
int a,num,ans=0;
printf("Enter an integer:\n");
scanf("%d",&num);
while (num>0)
{
a=num%10;
ans=ans+a;
num=num/10;
}
printf("%d is the sum of the number",ans);
}
