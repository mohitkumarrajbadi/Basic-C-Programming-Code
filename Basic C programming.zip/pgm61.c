/*Prorgram to enter number to dynamic memory allocation and print their square*/
#include<stdio.h>
#include<stdlib.h>
void main()
{
	int *ptr,i,n;
	printf("Enter the number of element :");
	scanf("%d",&n);

	ptr=(int*)malloc(n*sizeof(int));
	if(ptr == NULL)
	{
		printf("Out of memory!!");
		exit(0);
	}

	printf("Enter the elements of array : ");
	for(i=0;i<n;++i)
		{
		scanf("%d",(ptr+i));
		}

	printf("The array elements are:");
	for(i=0;i<n;++i)
		{
		*(ptr+i) *= *(ptr+i);
		printf("%d\n",*(ptr+i));	
		}
}
	
