//Program for the Hotel Billing(i.e for idli,dosa,etc)//

#include<stdio.h>
void main()
{
	int sd=75,md=125,tea=50,coffee=75,bill=0,plates,choice;
	printf("Enter your choice (1,2,3,4,5):");
	scanf("%d",&choice);

	switch (choice)
	{
	case 1:
	printf("\nEnter no of plates you want: ");
	scanf("%d",&plates);
	bill=sd*plates;
	printf("Bill:You are requested to pay RS:%d in the counter.....\n THANK YOU VISIT AGAIN",bill); 
	break;
	
	case 2:
	printf("\nEnter no of plates you want:");
	scanf("%d",&plates);
	bill=md*plates;
	printf("Bill:You are requested to pay RS:%d in the counter.....\n THANK YOU VISIT 			AGAIN",bill); 
	break;

	case 3:
	printf("\nEnter no of cup you want:");
	scanf("%d",&plates);
	bill=tea*plates;
	printf("\nBill:You are requested to pay RS:%d in the counter.....\n THANK YOU VISIT 				AGAIN \n",bill); 
	break;

	case 4:
	printf("\nEnter no of cup you want:");
	scanf("%d",&plates);
	bill=coffee*plates;
	printf("\nBill:You are requested to pay RS:%d in the counter.....\n THANK YOU VISIT 			AGAIN \n",bill); 
	break;

	case 5:
	bill=15;
	printf("Bill:You are requested to pay Rs:%d in the counter.....\n THANK YOU VISIT AGAIN",bill); 
	break;

	default:
	printf("The menu is not available....\n THANK YOU VISIT AGAIN.....\n");
	}
}
