/*Program to display array element using the pointer*/
#include<stdio.h>
void main()
{
int *p,i;
int x[5]={1,2,3,4,5};
i=0;
p=x;
printf("Element Value Address:\n");
for(i=0;i<5;i++){
	printf(" x[%d] : %d\n",i,*p);
	p++;
	}
}
