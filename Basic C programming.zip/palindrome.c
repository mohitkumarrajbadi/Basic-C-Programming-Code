//Program to check a string is Palindrome or not//

#include<stdio.h>
void main()
{
	char str[100],h,l=0,len=0;
	printf("Enter string:\n");
	scanf("%s",str);
	for(len=0;str[len]!='\0';len++);
	h=len-1;	
	while(h>l)
	    {
		if(str[l++] != str[h--])
		{	
		printf("%sIs not Palindrome\n",str);
		return;
		}
	     }
printf("%s is palindrome",str);
}
