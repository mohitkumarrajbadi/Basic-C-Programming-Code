/*Program to generate fabonacci series of given number of term*/
#include<stdio.h>
void main()
{
int x=0,y=1,z,n;
printf("Enter the number to get the fabonacci series:\n");
scanf("%d",&n);
printf("The fabonacci series is:\n");
printf("%d\t",x);
printf("%d\t",y);
while(x<=n)
	{
	z=x+y;
	printf("%d\t",z);
	x=y;
	y=z;	
	}
}
