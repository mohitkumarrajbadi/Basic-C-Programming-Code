/*Program to input matrix and perform operations*/

#include<stdio.h>
void dis(int x[][3]);
void nom(int x[][3]);
void sum(int x[][3]);
void zero(int x[][3]);

void main(){
int arry[3][3],i,j;
printf("Enter the array element:\n");
for(i=0;i<3;i++)
	for(j=0;j<3;j++)
		scanf("%d",&arry[i][j]);

char ch='y';
while(ch=='y' || ch=='Y'){
int choice;
printf("Enter your choice to perform the task:\n1.Display the perimeter elements\n2.Display the non perimeter element\n3.Find the sum of the perimeter element\n4.Display zero in place of non parameter element");	
scanf("%d",&choice);
switch(choice){
	case 1: dis(arry);
		break;
	case 2: nom(arry);
		break;
	case 3: sum(arry);
		break;
	case 4: zero(arry);
		break;
		}
	printf("\nDo you want to continue:\n");
	scanf(" %c",&ch);
	}
}


void dis(int x[][3]){
int i,j;
int mid=3/2;
for(i=0;i<3;i++){
	for(j=0;j<3;j++)
	{	
		if(i==j && j==mid)
		printf("%d\t",x[i][j]);				
		}
	}
}



void nom(int x[][3]){
int i,j;
int mid=3/2;
for(i=0;i<3;i++){
	for(j=0;j<3;j++)
	{	
		if(i==j && j==mid)
		printf(" \t");
		else
		printf("%d\t",x[i][j]);				
		}
	printf("\n");
	}
}



void sum(int x[][3]){
int i,j;
int sum=0;
int mid=3/2;
for(i=0;i<3;i++){
	for(j=0;j<3;j++)
	{	
		if(i==j && j==mid){}
		else
		sum=sum+x[i][j];				
		}
	}
printf("\nThe sum of the array is:%d\n",sum);
}


void zero(int x[][3]){
int i,j;
int mid=3/2;
for(i=0;i<3;i++){
	for(j=0;j<3;j++)
	{	
		if(i==j && j==mid)
		printf("%d\t",x[i][j]);
		else
		printf("0\t");				
		}
	printf("\n");
	}
}


