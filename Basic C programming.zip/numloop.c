#include <stdio.h>
void main()
{
int a,b;
system("clear");
         for(a=1;a<=5;a++)
	{	
		for(b=1;b<=25;b++)
		{
		if(a>b) printf("%d",a); 
 		printf("\t");
		}
	printf("\n");
	}
}
