/*Program to make a structure and sort record according to price*/
#include<stdio.h>
struct books{
	long bid;
	char bname[50];
	int bpy;
	char aut[50];
	float price;
	};

void main(){
	struct books a[5],b;
	int i,j;	
	for(i=0;i<5;i++){
	printf("Book-Id : ");
	scanf("%ld",&a[i].bid);
	printf("Book-Name : ");
	scanf("%s",a[i].bname);
	printf("Book-Publication-Year : ");
	scanf("%d",&a[i].bpy);
	printf("Author : ");
	scanf("%s",a[i].aut);
	printf("Price : ");
	scanf("%f",&a[i].price);
	}

	for(i=0;i<5;i++){	
		for(j=i+1;j<5;j++)
		if(a[i].price<a[j].price)		
			{	
			b=a[i];
			a[i]=a[j];
			a[j]=b;				
				}			
		}

	for(i=0;i<5;i++){
		printf("\n");
		printf("Book_id : %ld \n",a[i].bid);
		printf("Book_Name : %s \n",a[i].bname);
		printf("Book_Publication_Year : %d \n",a[i].bpy);
		printf("Author : %s \n",a[i].aut);
		printf("Price : %f \n",a[i].price);
		}
	}
