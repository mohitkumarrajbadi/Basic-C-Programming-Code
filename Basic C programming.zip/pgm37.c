/*Programm to perform matrix addition*/

#include<stdio.h>
void main()
{
int i,j,x,y;

printf("ENTER THE NUMBER OF THE ROW AND COLUMNS\n:");
scanf("%d %d",&x,&y);

int a[10][10],b[10][10],c[10][10];

printf("Enter the first array element:\n");
for(i=0;i<x;i++)
{
for(j=0;j<y;j++)
{
scanf("%d",&a[i][j]);
}
}

printf("Enter the second array element:\n");
for(i=0;i<x;i++)
for(j=0;j<y;j++)
scanf("%d",&b[i][j]);


for(i=0;i<x;i++)
for(j=0;j<y;j++)
{
c[i][j]=a[i][j]+b[i][j];
}


printf("THe matrix addition is:\n");

for(i=0;i<x;i++)
{
	for(j=0;j<y;j++)
	{
	printf("%d\t",c[i][j]);
	}
	printf("\n");
	}
}
