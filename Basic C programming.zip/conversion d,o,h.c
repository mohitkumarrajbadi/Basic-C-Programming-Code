#include<stdio.h>
void main()
{
 int a=171,b=0123,c=0x123;
 system ("clear");
 printf("Decimal Value of a=%d,b=%d,c=%d\n",a,b,c);
 printf("Octal value of a=%o,b=%o,c=%o\n",a,b,c);
 printf("Hexadecimal value of a=%x,b=%x,c=%x\n\n",a,b,c);	
 printf("Octal value of a=%#o,b=%#o,c=%#o\n",a,b,c);		
 printf("Hexadecimal value of a=%#x,b=%#x,c=%#x\n",a,b,c);
 printf("Hexadecimal value of a=%#x,b=%#x,c=%#x",a,b,c);
}
