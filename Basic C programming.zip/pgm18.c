/*Program to generate the pattern

1
2 3
4 5 6
7 8 9 10

*/

#include<stdio.h>
void main()
{
int num=1;
int i,j;
	for(i=0;i<4;i++)
	{
	for(j=0;j<=i;j++)
	{
		printf("%d\t",num);
		num=num+1;	
	}
	printf("\n");
	}
}
