/*Program to generate electric bill by taking input ..*/
#include<stdio.h>
void main()
{
int cno,pmr,cmr;
float units=0,charges=0;
char cna[30];
printf("Enter the consumer number:\n");
scanf("%d",&cno);
printf("Enter the name of the consumer:\n");
scanf("%s",cna);
printf("Enter the previous meter reading:\n");
scanf("%d",&pmr);
printf("Enter the current meter reading:\n");
scanf("%d",&cmr);
units=cmr-pmr;
	if(units<=100)
		{
		charges=units*2;
		}
	else if(units>100 && units<=200)
		{
		units=units-100;
		charges=units*3+200;
		}
	else if(units>200 && units<=300)
		{
		units=units-200;
		charges=units*4.50+500;
		}
	else if(units>300 && units<=500)
		{
		units=units-300;
		charges=units*5.50+950;
		}
	else
		{	
		units=units-500;
		charges=units*7.00+2050;	
		}
printf("\n\nConsumer Number:%d\n",cno);
printf("Consumer Name:%s\n",cna);
printf("Charges:%f\n\n\n\n",charges);
}

