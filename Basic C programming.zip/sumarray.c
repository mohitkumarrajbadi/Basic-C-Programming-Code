//Program to print sum of the array//

#include<stdio.h>
void main()
{
	int num[10],i,sum=0,average=0;
	printf("Enter the array\n");
	for(i=0;i<10;i++)
	{
		scanf("%d",&num[i]);
	}
	printf("Enter the sum\n");
	for(i=0;i<10;i++)
	{
		sum=sum+num[i];
	}
	printf("Sum of the number:%d\n",sum);
	average=sum/10;
	printf("Average:%d\n",average);
}
