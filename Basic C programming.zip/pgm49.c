/*Program to perform addition and subtraction of complex number using structure */
#include<stdio.h>
void main()
{
struct complex{
	int rel;
	int img;
	}com[2];				
	
char ch='y';
while(ch=='y' || ch=='Y'){
	int i,j,ar=0,ai=0;
	for(i=0;i<2;i++){
		printf("\nEnter the real num of %d number : ",i+1);		
		scanf("%d",&com[i].rel);
		printf("\nEnter the imaginary num of %d number : ",i+1);
		scanf("%d",&com[i].img);
		}
	
			for(i=0;i<2;i++){
			ar=ar+com[i].rel;
			ai=ai+com[i].img;
				}	
			printf("\n The sum of %d + %dr : %d \n",com[0].rel,com[1].rel,ar);
			printf("\n The sum of %d + %di : %d \n",com[0].img,com[1].img,ai);
				
				for(i=0;i<1;i++){		
				ar=com[i].rel-com[i+1].rel;
				ai=com[i].img-com[i+1].img;
					}
			printf("\n The sub of %d - %dr : %d \n",com[0].rel,com[1].rel,ar);
			printf("\n The sub of %d - %di : %d \n",com[0].img,com[1].img,ai);	
		printf("\nDo you want to continue : \n");	
		scanf(" %c",&ch);
		}
}
