#include<stdio.h>
void main()
{
int a=3;
if(a=5)
{
printf("OK");
}							
else
{
printf("NOT OK");
}
printf("%d",ad);
}
