/*Program to convert decimal to binary*/

#include<stdio.h>
void main()
{
int num,rem,;
printf("Enter the number:");
scanf("%d",&num);
while(num!=0)
	{
	rem=num%2;
		
	}
}
