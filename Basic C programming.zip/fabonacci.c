//Print out the Fabonacci series//
#include<stdio.h>
void main()
{
	int pno=0,cno=1,nno,count;
	printf("%d\n %d\n",pno,cno);
	count=2;
	while(count<10)
	{
	nno=pno+cno;
	printf("%d\n",nno);
	count++;
	pno=cno;
	cno=nno;
	}
}
