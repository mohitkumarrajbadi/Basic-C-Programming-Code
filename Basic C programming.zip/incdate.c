//Program to read and increase the date by 1// 

#include<stdio.h>
void main()
{
	int year,t,f;
	int date;
	printf("Enter the date:");
	scanf("%d",&date);
	int month;
	printf("Enter the month(1-12):");
	scanf("%d",&month);
//Checking leap year or not
	printf("Enter the year(4-digit):");
	scanf("%d",&year);
	if (year%4==0)
	{
		if(year%100==0)
	{	if(year%400==0)
			t=1;
		else
			t=0;
	}
	else
	 	t=1;
	}

//Printing proccess of the leap year
if(t==1)
{	
	switch (month)
	{	
		case 1:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 2:
			if(date==29)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>29)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 3:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 4:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 5:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 6:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 7:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 8:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 9:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 10:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 11:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 12:
			if(date==31)
			{
				date=1;
				month=1;
				int newyear; newyear=year+1;
				printf("Happy New Year:%d:%d:%d\n",date,month,newyear);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		default:
			printf("Dear friend enter the correct month!!!!\n");
			}
}
//Printing the normal year
else
	switch (month)
	{	
		case 1:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 2:
			if(date==28)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>28)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 3:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 4:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 5:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 6:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 7:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 8:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 9:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 10:
			if(date==31)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 11:
			if(date==30)
			{
				date=1;
				month+=1;
				printf("%d:%d:%d\n",date,month,year);  }       	
			else	
		     {
					 if(date>30)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		case 12:
			if(date==31)
			{
				date=1;
				month=1;
				int newyear; newyear=year+1;
				printf("Happy New Year:%d:%d:%d\n",date,month,newyear);  }       	
			else	
		     {
					 if(date>31)
						printf("Enter your date correctly\n");

					else
					{
						date+=1;
						printf("%d:%d:%d\n",date,month,year);
						}
			}		
			break;
		default:
			printf("Dear friend enter the correct month!!!!\n");
			}
}




