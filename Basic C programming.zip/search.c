//Program to search an element in the array//

#include<stdio.h>
void main()
{
	int no[10],a,b;
	printf("Enter the element in the array:\n");
	for(a=0;a<10;a++)
	{
		scanf("%d",&no[a]);
	}
	printf("Enter the number you want to check in the array:\n");
	scanf("%d",&b);
	for(a=0;no[a]!='\0';a++)
	{
		if(no[a]==b)
		printf("The no you are searching for is in the %d position.",a);	
	}
}
