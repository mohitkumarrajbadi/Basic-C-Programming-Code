#include<stdio.h>
void main()
{
	int num,i,prime=0;
	printf("Enter the number you want to check the prime number or not:\n");
	scanf("%d",&num);
	for(i=2;i<=num/2;++i)
	{
		if(num%i==0)
			{
			prime=1;
	}
}
	if (prime==0)
	printf("Prime\n");
	else
	printf("Not Prime\n");
	}

