/*Program to check the number is palindrome or not*/
#include<stdio.h>
void main()
{
int num,k,rem=0,rev=0;
printf("Enter the number:");
scanf("%d",&num);
k=num;
while(num!=0)
{
rem=num%10;
rev=rev*10+rem;
num=num/10;
}
if(k==rev)
printf("Palindrome");
else
printf("Not palindrome");
}
