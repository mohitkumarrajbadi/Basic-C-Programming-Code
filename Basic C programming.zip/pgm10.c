/*Program to input a string and display there ASCII value*/
#include<stdio.h>
void main()
{
char ch[10];
int a=0,i;
printf("Enter the string:");
gets(ch);
for(i=0;i<10;i++)
	{
	a=a+ch[i];
	}
printf("THe ASCII value of %s is %d;",ch,a);
}

