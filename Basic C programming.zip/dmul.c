/*Program to display the diagonal of an matrix*/

#include<stdio.h>
void main()

{
int array[4][4];
int i,j,K,L;
printf("Enter the elements of the array:");
for(i=0;i<4;i++)
	for(j=0;j<4;j++)
	{
	scanf("%d",&array[i][j]);
	}
printf("\nThe right diagonal is:\n");
for(i=0;i<4;i++)
	for(j=0;j<4;j++)
	{
		if(i==j)
		printf("%d",array[i][j]);	
	}
printf("\nThe left diagonal is:\n");
for(K=3;K>3;K--)
	for(L=3;L>3;L--)
	{
		if(K==L)
		printf("%d",array[K][L]);	
	}

}
