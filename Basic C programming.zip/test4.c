/*Program to check a digit is Armstrong or not*/

#include<stdio.h>
#include<math.h>
void arm(int num);
void main()
{
int num;
printf("Enter the number:\n");
scanf("%d",&num);
arm(num);
}

void arm(int num)
{
int clone=0,clone2=0,rem,ans,digit=0;
clone=num;
clone2=num;
	while(clone!=0){
		clone=clone/10;
		digit++;		
		}

	while(clone2!=0){
		rem=clone2%10;
		ans=ans + pow(rem,digit);
		clone2=clone2/10;
		}
	if(ans==num){
	printf("The number is armstrong number;\n");	
	}
	else
	printf("The number is not armstrong number;\n");
}
