/*Program to input dob and current date through structure and calculate the age in year months and days*/

#include<stdio.h>

void main()
{
struct age{
	int dd;
	int mm;
	int yyyy;	
	}a[2];
int i;
for(i=0;i<2;i++){
	printf("Enter the date (dd): ");
	scanf("%d",&a[i].dd);
	printf("Enter the month (mm): ");
	scanf("%d",&a[i].mm);
	printf("Enter the year (yyyy): ");
	scanf("%d",&a[i].yyyy);
	}

int date,month,year;

	if(a[1].dd>a[0].dd)
	{
	date=a[1].dd-a[0].dd;
	}
	else
	{
		a[1].dd=a[1].dd+30;
		a[1].mm=a[1].mm-1;
		date=a[1].dd-a[0].dd;
	}
	

	if(a[1].mm>a[0].mm)
	{
		month=a[1].mm-a[0].mm;
	}
	else
	{
		a[1].mm=a[1].mm+12;
		a[1].yyyy=a[1].yyyy-1;
		month=a[1].mm-a[0].mm;
	}	

	if(a[1].yyyy>a[0].yyyy)
	{
		year=a[1].yyyy-a[0].yyyy;
	}
	else
	{
		a[1].dd=a[1].dd-365;
		a[1].yyyy=a[1].yyyy+365;
		year=a[1].yyyy-a[0].yyyy;
	}
	
	
	date=a[1].dd - a[0].dd;
	month=a[1].mm - a[0].mm;
	year=a[1].yyyy - a[0].yyyy;

	

	printf("\n\n The age is %d years , %d months , %d days;\n",year,month,date);
}
