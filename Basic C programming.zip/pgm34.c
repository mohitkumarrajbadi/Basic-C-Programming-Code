/*Program to input employee id,Name and Basic Salaryand calculate ta=35% da=75% of basic,pf=18% of basic*/
#include<stdio.h>

float gross(float a,float b,float c ,float d);
float net(float x,float y);

void main()
{
long empid;
char name[50];
float bsal,ta,da,hra,pf;
float g,n;
printf("ENTER THE EMPLOYEE ID"); 
scanf("%ld",&empid);
printf("ENTER THE EMPLOYEE NAME");
scanf("%s",name);
printf("ENTER THE EMPLOYEE BASIC SALARY");
scanf("%f",&bsal);
ta=.35*bsal;
printf("The TA is:%f\n",ta);
da=.75*bsal;
printf("The DA is:%f\n",da);
hra=.30*bsal;
printf("The HRA is:%f\n",hra);
pf=.18*bsal;
printf("The PF is:%f\n",pf);
g=gross(bsal,ta,da,hra);
printf("The gross is:%f\n",g);
n=net(g,pf);
printf("The net amount is %f\n",n);
}

float gross(float a,float b,float c ,float d){
	int gr;
	gr=a+b+c+d;
	return gr;
}

float net(float x,float y){
	int nt;
	nt=x-y;
	return nt;	
	}
