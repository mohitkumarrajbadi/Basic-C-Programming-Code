/*Program to pass matrix through function and display its elements*/

#include<stdio.h>
void disp(int a[3][3]);

void main()
{
	int arry[3][3],i,j;
	printf("Enter the elements in the array:");
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
	scanf("%d",&arry[i][j]);
	disp(arry);
}

void disp(int a[3][3]){
	int i=0,j=0;
	for(i=0;i<3;i++)
	{
	for(j=0;j<3;j++)
	printf("%d \t",a[i][j]);
	printf("\n");
	}
}
