/*Program to input 10 elements in an array & and split into two diffirent array*/

#include<stdio.h>
void main()
{
int array[10],i,num;
printf("Enter the array elements:");
for(i=0;i<10;i++)
{
scanf("%d",&array[i]);
}
printf("Enter the given number:");
scanf("%d",&num);

printf("\nThe Actual array elements are:\n");
for(i=0;i<10;i++)
	{
	printf("%d\n",array[i]);
	}
printf("\n The first split element are:\n ");
for(i=0;i<num;i++)
	{
	printf("%d\n",array[i]);
	}

printf("\n The second split element are:\n ");
for(i=num;i<10;i++)
	{
	printf("%d\n",array[i]);
	}
}
