//Program to read 10 numbers and display the biggest without using array//

#include<stdio.h>
void main()
{
	int no,bigno,count;
	printf("Enter 1st number:");
	scanf("%d",&bigno);
	count=1;
	while(count<10)
	{
	count++;
	printf("Enter %d th number:",count);
	scanf("%d",&no);
	if(no>bigno)
		bigno=no;
	}
printf("%d is lagrest",bigno);
}
