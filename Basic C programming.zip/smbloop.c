#include <stdio.h>
void main()
{
	int a,b;
	system("clear");
        for(a=1;a<=4;a++)
	{	
		for(b=1;b<=4;b++)
		{
		if(a==b) printf("=");
		else if(a>b) printf(">");
		else printf("<");
		}
	printf("\n");
	}
}
