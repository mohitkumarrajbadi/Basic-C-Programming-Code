/*Program to input personal data for multiple persons and display it*/

#include <stdio.h>
void main(){
struct personaldata{
	char name[25];
	char address[50];
	long mobile;
	char dob[10];
	struct academicdata{
		int rollno;
		char course[5];
		int sem;
		char uni[25];
		float cgpa;	
		}b[5];
	}a[5];

	int i=0;
	for(i=0;i<5;i++)
	{
	printf("Enter the name :\n");
	scanf("%s",a[i].name);
	printf("Enter the address :\n");
	scanf("%s",a[i].address);
	printf("Enter mobile number : \n");
	scanf("%ld",&a[i].mobile);
	printf("Enter the date of birth (dd/mm/yyyy): \n");
	scanf("%s",a[i].dob);
	
	printf("Enter the rollno : \n");
	scanf("%d",&a[i].b[i].rollno);
	printf("Enter the Course : \n");
	scanf("%s",a[i].b[i].course);
	printf("Enter the sem number : \n");
	scanf("%d",&a[i].b[i].sem);
	printf("Enter the name of the University : \n");
	scanf("%s",a[i].b[i].uni);
	printf("Enter the cgpa : ");
	scanf("%f",&a[i].b[i].cgpa);
	}

	for(i=0;i<5;i++){
	printf("\n\n	Name : %s \n",a[i].name);
	printf("	Address : %s \n",a[i].address);
	printf("	Mobile No : %ld \n",a[i].mobile);
	printf("	DOB : %s \n",a[i].dob);
	printf("	RollNo : %d \n",a[i].b[i].rollno);
	printf("	Course : %s \n",a[i].b[i].course);
	printf("	Semester : %d \n",a[i].b[i].sem);
	printf("	University Name : %s \n",a[i].b[i].uni);
	printf("	Cgpa : %f \n",a[i].b[i].cgpa);	
	}
}
