/*Program to input data and give the output*/
#include<stdio.h>

struct machine{
		long mid;
		char mname[20];
		int out;
		int work;
			}m[3];



void fun(struct machine m[]){
	
	int i,sum=0;
		
		for(i=0;i<3;i++){
			printf("\n\n\n");
			printf("Machine id : %ld \n",m[i].mid);
			printf("Machine Name : %s \n",m[i].mname);
			printf("Output Quantity : %d \n",m[i].out);
			printf("Work Time : %d \n",m[i].work);	
			sum=sum+m[i].out;
			printf("\n\n\n");	
		}	

	printf("The total number of output is : %d \n\n\n",sum );
	}



	void main()
	{
		int i;
		for(i=0;i<3;i++){
		printf("Machine id : ");
		scanf("%ld",&m[i].mid);
		printf("Machine Name : ");
		scanf("%s",m[i].mname);
		printf("Output Quantity : ");
		scanf("%d",&m[i].out);
		printf("Work Time : ");	
		scanf("%d",&m[i].work);	
		}
		fun(m);
	}


