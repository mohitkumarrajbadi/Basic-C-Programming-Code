/*Program to display prime number in a range of number using function*/
#include<stdio.h>

int prime(int a);

void main()
{
int num,n,flg=1;
printf("Enter the lowrange and uprange: ");
scanf("%d %d",&num,&n);

while(num<=n)
	{
	flg = prime(num);
	if(flg==0)
		{
		printf("%d\t",num);
		}
	num=num+1;
	}
}

int prime(int a)
	{
	int flag=0,i=0;
	for(i=2;i<=a/2;i++)
		{
			if(a%i==0)
			{
			flag=1;
			break;
			}
			else
			{
			flag=0;
			}
		}	

	return flag;
	}
	
