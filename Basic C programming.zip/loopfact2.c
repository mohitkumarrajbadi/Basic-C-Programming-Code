#include<stdio.h>
#include<math.h>
void main()
{
 int x,n,i,sum=0,num;
	printf("Enter a number:\n");
	scanf("%d",&x);
printf("Enter the value of n:\n");
scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		num=pow(x,i); 
		sum=sum+1/num;
	}
printf("The answer is :%d ",sum);
}
