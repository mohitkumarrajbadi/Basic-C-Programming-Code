/*Program to print char pattern*/
#include<stdio.h>
void main(){
int i,j,k;
char ch[5]={'m','o','h','i','t'};

for(i=0;i<5;i++)
	{
	for(k=0;k<i;k++)
		printf(" ");
	for(j=i;j<=5-(i*2);j++)
		{
		printf("%c",ch[j]);
		}
		printf("\n");
	}
}
