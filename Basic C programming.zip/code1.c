//Checking the output//
#include<stdio.h>	
int main()
{
	int x=5%2*3/2;
	printf("%d",x);
	return 0;
}
