/*Program to input a number and check that it is palindrome or not*/

#include<stdio.h>
int reverse(int a);
void main()
{
int num,pal;
printf("Enter the number :\n");
scanf("%d",&num);
pal=reverse(num);

if(num==pal)
printf("\nPalindrome\n");
else
printf("\nNot Palindrome\n");
}

int reverse(int a){
int rem,rev;
while(a!=0)
	{
	rem=a%10;
	rev=rev*10+rem;
	a=a/10;
	}
return rev;
}

