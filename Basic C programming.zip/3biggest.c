//Program to print Biggest number among 3 without using 4th integer// 

#include <stdio.h>
void main()
{
	int a,b,c;
	printf("Enter three number to check the biggest one:");
	scanf("%d %d %d",&a,&b,&c);
	
	if(a>=b && a>=c)
		printf("%d is the biggest number:",a);
	if(b>=a && b>=c)
		printf("%d is the biggest number:",b);
	if(c>=a && c>=b)
		printf("%d is the biggest number:",c);
}
