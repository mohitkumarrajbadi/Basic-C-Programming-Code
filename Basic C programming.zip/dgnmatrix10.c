//Pogram to print a matrix of 10*10 multiple//

#include<stdio.h>
void main()
{
	int a,b;		
	for(a=1;a<=10;a++)
	{
	for(b=1;b<=10;b++)
	{
	printf("%d\t",a*b);
	if(b%10==0)
	printf("\n");	
	}
	}
}
