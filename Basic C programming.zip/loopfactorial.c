#include<stdio.h>
#include<math.h>
void main()
{
	int x,n,num,f=1,i;
	double k,sum=0;
printf("Enter number of terms: \n");
scanf("%d",&n);
printf("Enter number of terms: \n");
scanf("%d",&x);
printf("The series is:");
for(i=0;i<n;i++)
{
	num=i;
if(num==0)
f=1;
else
{
f=1;
while(num>0)
{
f=f*num;
}
k=pow(x,i);
sum=sum+(k/f);
printf("%d / %d \t",(int)k,f);
{
 printf("Sum 1 series%lf \t",sum);
}
}
}
}
