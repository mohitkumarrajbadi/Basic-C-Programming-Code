/*Program to display your name 10 times using recursive function*/

#include<stdio.h>
void name(char* n,int count);

int main()
{
char num[50];
printf("Enter your name:\n");
gets(num);
name(num,0);
return 0;
}

void name(char* n,int count)
	{
	printf("%d : %s\n",count+1,n);
	count+=1;
	if(count<10)
		{
		name(n,count);
		}
	}
