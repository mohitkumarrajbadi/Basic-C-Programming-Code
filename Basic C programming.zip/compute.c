//Program to compute the (sum=x^n/i!) by entering x and i value//
#include<stdio.h>
#include<math.h>
void main()
{
	int sum,x,n,i,fact=1;
	printf("Enter the exponent and power value:\n ");
	scanf("%d %d",&x,&n);
	printf("Enter the number for the factorial:\n");
	scanf("%d",&i);
	while(i!=0)
	{
		fact=fact*i;
		i--;
	}
	sum=pow(x,n)/fact;
printf("The ans is:%d\n",sum);	
}
