#include <stdio.h>
void main()
{
	int i=1;
	while((i*i)<1000)
{
 	printf("%d\t",i*i);
	i++;	
}
}
