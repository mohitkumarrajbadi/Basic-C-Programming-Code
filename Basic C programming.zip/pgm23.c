/*PRO GRAM TO CHECK PRIME OR NOT USING FUNCTION*/
#include<stdio.h>
int prime();
int main()
{

int i,n,flag=0;
n = prime();
for(i=2;i<n/2;++i)
	{
	if(n%i==0)
	flag=1;
	else
	flag=0;
	}
if(flag==0)
printf("This is a prime number");
else
printf("This is not number");
}

int prime()
{
int n;
printf("Enter the number");
scanf("%d",&n);
return n;
}
