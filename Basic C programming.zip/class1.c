/*Program to find fibonacci series of the number uding recursive function*/


#include<stdio.h>
int fib(int a);

void main()
{
int n,i=0,c;
scanf("%d",&n);

printf("Fabonacci series:\n");

for(c=0;c<=n;c++)
	{
	printf("%d\n",fib(i));	
	i++;
	}
}

int fib(int a){
if(a==0)
return 0;
else if(a==1)
return 1;
else
return (fib(a-1)+fib(a-2));
}
