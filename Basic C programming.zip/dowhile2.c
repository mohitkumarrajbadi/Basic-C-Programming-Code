#include<stdio.h>
void main()
{	int a=1;
	do;
	while(a++);
	printf("%d",a);
}
