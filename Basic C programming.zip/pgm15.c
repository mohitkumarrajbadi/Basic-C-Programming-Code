/*PROGRAM TO INPUT ELEMENTS IN A SINGLE DIMENSION ARRAY & FIND THE DUPLICATE ELEMENTS IF PRESENT*/

#include<stdio.h>
void main()
{
	int ar[10],i,j;
	printf("Enter the value of the element:\n");
	
	for(i=0;i<10;i++)
	{
	scanf("%d",&ar[i]);
	}
	for(i=0;i<10;i++)
	{
	for(j=i+1;j<10;j++)
		if(ar[i]==ar[j])
				{
				printf("The similar element is:%d\n",ar[i]);
				}
	}
}
