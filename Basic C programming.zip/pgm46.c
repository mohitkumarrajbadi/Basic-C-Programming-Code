/*Program to input employee details*/

#include<stdio.h>
void main()
{
struct employee{
	long empid;
	char name[25];
	float basic;
	}emp;

	printf("Enter the Employee Id: ");
	scanf("%ld",&emp.empid);
	printf("Enter the Name: ");
	scanf(" %s",emp.name);
	printf("Enter the Basic Salary: ");
	scanf(" %f",&emp.basic);


	float gross,net;
	float ta,da,hra,pf;
	
	ta=0.45*emp.basic;
	da=0.70*emp.basic;
	hra=0.35*emp.basic;
	pf=0.24*emp.basic;
	
	gross = emp.basic + ta +  da + hra;
	net=gross-pf;

	printf("\nEmployeeId: %ld \n",emp.empid);
	printf("Employee Name: %s\n",emp.name);
	printf("The Gross Amount : %f \n",gross);
	printf("The Net Amount : %f \n",net);
	}

