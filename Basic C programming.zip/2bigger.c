//Program to print the biggest no among of two//

#include<stdio.h>
void main()

{
	int a,b;
	printf("Enter two number to fimd the greater one:");
	scanf("%d %d",&a,&b);
	if(a>b)
	printf("%d is the biggest number",a);
	else
	printf("%d is the biggest number",b);						
}
