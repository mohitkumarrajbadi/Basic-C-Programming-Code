#include<stdio.h>
#include<math.h>
void main()
{
	int x,n,count=1,sum;
	printf("Enter two num:\n");
	scanf("%d%d",&x,&n);
	while(n!= 0)
	{
	count=count*n;
	n--;
	}

	sum =(x,n)/count;
printf("%d",sum);
}
	
