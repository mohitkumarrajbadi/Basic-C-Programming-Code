//Program to print the even and odd number of an array//

#include<stdio.h>
void main()
{
	int num[10],i;
	printf("Enter the 10 elements:\n");
	for(i=0;i<10;i++)
	{
	scanf("%d",&num[i]);
	}

	for(i=0;i<10;i++)
	{
		if(num[i]%2==0)
		{
		printf("%d is Even\n",num[i]);
		}
		else
		{
		printf("%d is Odd\n",num[i]);
		} 
	}
}
