/*Program to find the greatest,smallest and sum of 10 number*/
#include<stdio.h>
void main()
{
int num,i,greatest=0,smallest=0,sum=0,k;
printf("Enter the number:");
scanf("%d",&num);
greatest=num;
smallest=num;
k=num;
for(i=0;i<9;i++)
{
printf("Enter other number:");
scanf("%d",&num);
if(num>greatest)
greatest=num;
if(num<smallest)
num=smallest;
sum=sum+num;
}
sum=k+sum;
printf("%d is the smallest number\n",smallest);
printf("%d is the greatest number \n",greatest);
printf("%d is the sum number\n",sum);
}
