#include<stdio.h>
void main()
{
int a=12;
while(a);
printf("%d",a);
}
