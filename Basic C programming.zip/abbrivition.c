//Print the abbrivition of a string(i.e mohit kumar should print mk)//

#include<stdio.h>
void main()
{
	char ch,str[100];
	int i=1;
	printf("Enter a string to get the abbriviations:\n");
	gets(str);
	printf("%c",str[0]);
	while(str[i]!='\0')
	{
	ch=str[i];
	if(ch==' ')
	{
		i++;
		printf("%c",str[i]);
	}
	i++;
	}
}
