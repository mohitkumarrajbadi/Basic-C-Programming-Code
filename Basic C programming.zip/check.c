//Checking the while loop function//
#include<stdio.h>
void main()
{
int a=10;
while(a)
{
printf("%d\n",a--);
}
printf("%d\n",a);
}
