/*Program to pass a array through function and perform operation such as*/


#include<stdio.h>

void sum(int a[],int b);
void avg(int a[],int b);
void sort(int a[],int b);
void mode(int a[],int b);
void median(int a[],int b);
void reverse(int a[],int b);
void frequency(int a[],int b);

void main()
{
int choice,num,i,j;
char ch='y';
printf("Enter the element in the array:\n");
scanf("%d",&num);

int array[num];
printf("Enter the value in the array:\n");
for(i=0;i<num;i++)
	{
	scanf("%d",&array[i]);
	}

while(ch=='y'|| ch=='Y'){
printf("Enter your choice for the task:\n1.to find the sum of the elements\n2.to find the average of the element\n3.sort the array element\n4.find the mode of the array\n5.print the median of an array \n6.reverse the array\n7.frequency of the array\n");
scanf("%d",&choice);
		switch(choice)
			{
			case 1: sum(array,num);
				break;
			case 2:avg(array,num);
				break;
			case 3:sort(array,num);
				break;
			case 4:mode(array,num);
				break;
			case 5:median(array,num);
				break;
			case 6:reverse(array,num);
				break;
			case 7:frequency(array,num);
				break;
			default:
				printf("\nINVALID CHOICE");

			}
	printf("\nDO YOU WANT TO CONTINUE:");
	scanf(" %c",&ch);	
	}
}


void sum(int a[],int b)
	{
	int i,ans;
	for(i=0;i<b;i++)
	ans+=a[i];
	printf("\nThe sum of the element in the array is: %d\n",ans);
	}

void avg(int a[],int b)
	{
	int i,ans;
	for(i=0;i<b;i++)
	ans+=a[i];
	ans=ans/b;
	printf("\nThe average of the array is:%d\n",ans);
	}

void sort(int a[],int b)
	{
	int temp,i,j;	
	for(i=0;i<b;i++)
	for(j=0;j<(b-i-1);j++)
	if(a[j]>a[j+1])
	{
		temp = a[j];
		a[j] = a[j+1];
		a[j+1] = temp;	
	}
printf("Sorted array is.......\n");
	for(i=0;i<b;i++)
	{
		printf("%d\n",a[i]);
	}
	
	}

void mode(int a[],int b){
int maxvalue=0,maxcount=0,i,j;
for(i=0;i<b;i++){
int count=2;
for(j=0;j<b;j++){
	if(a[j]==a[i])
	{
	++count;
	}
	}
	if (count > maxcount){
	maxcount=count;
	maxvalue=a[i];
	}
}
printf("\n Mode:%d\n",maxvalue);
}

void median(int a[],int b){
	int n;
	if(b%2==0)	
	{
	n=(a[(b/2)]+a[((b/2)+1)])/2;
	}
	else
	{
	n=a[((b+1)/2)];	
	}
	printf("The median of the element is:%d\n",n);
}

void reverse(int a[],int b){
	int i;
	for(i=b-1;i>=0;i--)
	{
	printf("%d\t",a[i]);	
	}
}



void frequency(int a[],int b)
{
	int i,j,k;
	for(i=0;i<b;i++){
		int count=1;
		for(j=i+1;j<b;j++){
			if(a[i]==a[j]){
				count=count+1;
				for(k=j;k<b-1;k++)
					{
					a[k]=a[k+1];				
					}		
					b--;	
				}	
			}
	printf("Element %d : Count %d \n",a[i],count);
	}
} 
