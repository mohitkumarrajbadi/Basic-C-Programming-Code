/*Program to input n number of element and search a given frequency*/
#include<stdio.h>
void main()
{
int array[100],n,i,j,num=1,element=0;
printf("Enter the number");
scanf("%d",&n);

for(i=0;i<n;i++)
	{
	scanf("%d",&array[i]);
	}

for(i=0;i<n;i++)
	{
	for(j=i+1;j<n;j++)
			
		{
		if(array[i]==array[j])
			{
			num=num+1;
			array[i++];
			}		
		}
		printf("The %d is %d times;\n",array[i],num);
		num=1;
	}
}
