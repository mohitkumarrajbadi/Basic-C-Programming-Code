//Program to display a output design//
//1  2  3   4  5//
//6  7  8   9 10//
//11 12 13 14 15//
//16 17 18 19 20// 
//21 22 23 24 25//

#include<stdio.h>
void main()
{
	int a,b;	
	for(a=1;a<=1;a++)
	{
	for(b=1;b<=25;b++)
	{
		printf("%d\t",b);
		if(b%5==0)
		printf("\n");
	}
	}
}
