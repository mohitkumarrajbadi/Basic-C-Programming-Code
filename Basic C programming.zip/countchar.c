//Program to count nos of character in a string//

#include<stdio.h>
void main()
{
	char ch[50];
	int i;
	printf("Enter the string:\n");
	gets(ch);
	for(i=0;ch[i]!='\0';i++);
	printf("The no of char in the string is:%d\n",i);
}
