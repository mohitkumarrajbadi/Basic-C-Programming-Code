/*Program to input all relevent data for a bus journey date of journey must be an embedded structure.Input data and display it*/

#include <stdio.h>
void main(){
struct pRdata{
		long tnum;
		char name[25];
		char from[20];
		char to[20];
		float time;
		struct doj{
			int date;
			int month;
			int year;	
			}b[1];
		}a[1];


	int i=0;
	for(i=0;i<1;i++)
	{
	printf("Enter the Ticket Number :\n");
	scanf(" %ld",&a[i].tnum);
	printf("Enter the Name :\n");	
	scanf("%s",a[i].name);
	printf("Enter the From Location : \n");
	scanf(" %s",a[i].from);
	printf("Enter the To Location : \n");
	scanf(" %s",a[i].to);
	printf("Enter the Departure Time : \n");
	scanf(" %f",&a[i].time);
	printf("Enter the date of journey : \n");	
	scanf(" %d/%d/%d",&a[i].b[i].date,&a[i].b[i].month,&a[i].b[i].year);
	}

	for(i=0;i<1;i++){
		printf("\n\n\nTicket Number : %ld \n",a[i].tnum);
		printf("Name : %s \n",a[i].name);
		printf("From : %s \n",a[i].from);
		printf("To : %s \n",a[i].to);
		printf("Date of Journey : %d/%d/%d \n",a[i].b[i].date,a[i].b[i].month,a[i].b[i].year);
		printf("Departure Time : %.2f\n",a[i].time);
	}
}
