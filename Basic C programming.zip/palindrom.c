#include<stdio.h>
void main()
{
int num,temp,reverse=0,reminder;
printf("Enter a integer\n");
scanf("%d",&num);
temp=num;
while(num>0)
{
reminder=num%10;
reverse=reverse*10+reminder;
num/=10;
}
printf("The reverse number is :%d\n",reverse);
if (temp==reverse)
printf("Number is a palindrome");
else
printf("Number is not a palindrome");
}
