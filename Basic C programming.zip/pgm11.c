/*Program two input number and multiply these using + sign*/
#include<stdio.h>
void main()
{
char ch;
int a,b,ans=0,i;
printf("Enter the numbers:");
scanf("%d %d",&a,&b);
for(i=0;i<a;i++)
	ans=ans+b;
printf("The answer is :%d\n",ans);

}
