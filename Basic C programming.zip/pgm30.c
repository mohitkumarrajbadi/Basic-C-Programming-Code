/*Program to find the factorial of a number using recursive function*/

#include<stdio.h>fuck shit
int fact(int a);
void main()
{
int num,ans;
printf("Enter the number:\n");
scanf("%d",&num);
ans=fact(num);
printf("The factorial of the number is :%d\n",ans);
}

int fact(int a)
	{
	if(a==1)
	return 1;
	else
	return (a*fact(a-1));
	}
