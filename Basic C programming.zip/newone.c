#include<stdio.h>
int main()
{
 printf("int=%d,char=%d\n",(sizeof()),(sizeof(char));
}
