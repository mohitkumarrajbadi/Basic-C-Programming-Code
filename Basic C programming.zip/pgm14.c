/*PROGRAM TO INPUT A NUMBER AND REDUCE IT TO SINGLE DIGIT BY REPEATEDLY ADDING ITS DIGITS*/
#include<stdio.h>
void main()
{
int num;
int rev,rem=0;
int ans=0,r=0;
printf("Enter the number you want to reduce:\n");
scanf("%d",&num);
	while(num!=0)
	{
	rem=num%10;
	ans=ans+rem;
	num=num/10;
	}
	while(ans!=0)	
		{
		rem=ans%10;	
		r=r+rem;
		ans=ans/10;	
		}
printf("Reduce %d\n",r);
}
