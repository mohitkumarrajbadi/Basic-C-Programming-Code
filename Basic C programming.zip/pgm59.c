/*Program to enter your personal data in unio and diaplay it*/

#include<stdio.h>
void main()
{

union personal{
	char name[20];
	long phone;
	char add[20];
	}a,b,c;
	
	printf("Enter the Name : ");
	scanf("%s",a.name);
	printf("Enter the Phone Number : ");
	scanf("%ld",&b.phone);
	printf("Enter the Address : ");
	scanf("%s",c.add);
	
	printf("\n\nName : %s \n",a.name);
	printf("Phone Number : %ld \n",b.phone);
	printf("Enter the Address : %s \n",c.add);
}
