/*Program to generate the electry bill*/

#include<stdio.h>
void main()
{
long cnum,mnum;
float unit,charge;
int pmr,cmr;
char cname[20];
printf("Enter the consumer name:\n");
gets(cname);
printf("Enter the consumer number:\n");
scanf("%ld",&cnum);
printf("Enter the Meter number:\n");
scanf(" %ld",&mnum);
printf("Enter the Previous Meter Reading and Current Meter Reading:\n");
scanf("%d %d",&pmr,&cmr);

unit=cmr-pmr;

printf("Electric Bill\n");
	if(unit<=100)
		{
			charge=unit*2.50;
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);	
		}
	else if(unit>100 && unit<=200){
			unit=unit-100;
			charge=250+(unit*3.00);
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);
		}
	else if(unit>200 && unit<=300){
			unit=unit-200;
			charge=550+(unit*4.50);
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);
		}
	else if(unit>300 && unit<=400){
			unit=unit-300;
			charge=1000+(unit*5.00);
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);
		}
	else if(unit>400 && unit<=500){
			unit=unit-400;
			charge=1500+(unit*6.00);
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);
		}
	else{
			unit=unit-500;
			charge=2100+(unit*7.50);
			printf("Name : %s\n",cname);
			printf("Consumer Number : %ld\n",cnum);
			printf("Cost : %f\n",charge);
			}
}
