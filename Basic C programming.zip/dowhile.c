#include <stdio.h>
void main()
{
int a=1;
do;
while(a++<=10);
printf("%d",a);
}
