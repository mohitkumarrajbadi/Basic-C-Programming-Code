/*Program to input necessary paramters and calculate area and parameter of	1.traingle	2.square	3.rectangle*/
#include<stdio.h>

void traingle();
void square();
void rectangle();

void main()
{
int choice,ch=1;
float a,b,c;
while (ch== 1)
{
printf("Enter the 1.Traingle 2.Square 3.Rectange:\n");
scanf("%d",&choice);
	switch(choice)
	{
	case 1:
		traingle();
		break;
	case 2:square();
		break;
	case 3:rectangle();
		break;
	default:
		printf("Invalid number choice\n");
	}
printf("\nDO YOU WANT TO  CONTINUE!!!!! 1(YES) AND 2(NO):\n");
scanf("%d",&ch);
}
}

void traingle(){
		int ch;
		float h,b,ar;
		float a,b1,c,pr;
		printf("Enter 1.Area 2. Perimeter\n");
		scanf("%d",&ch);
		switch(ch)
		{	
		case 1:	
			printf("Enter the height and breath:\n");		
			scanf("%f %f",&h,&b);
			ar=(h*b)/2;
			printf("\nArea:%f",ar);
			break;
		case 2:	
			printf("Enter the 3 sides of the traingle:\n");		
			scanf("%f %f %f",&a,&b1,&c);
			pr=a+b1+c;
			printf("\nPerimeter:%f",pr);
			break;			
			}
	
	}

void rectangle(){
		int ch;
		float a,b,pr;
		float l,w,ar;
		printf("Enter 1.Area 2. Perimeter\n");
		scanf("%d",&ch);
		switch(ch)
		{	
		case 1:	
			printf("Enter the length and weidth:\n");		
			scanf("%f %f",&l,&w);
			ar=l*w;
			printf("\nArea:%f",ar);
			break;
		case 2:	
			printf("Enter the length and weidth:\n");		
			scanf("%f %f",&a,&b);
			pr=2*(a+b);
			printf("\nPerimeter:%f",pr);
			break;			
			}
	}

void square(){
		int ch;
		float s,ar;
		float a,pr;
		printf("Enter 1.Area 2. Perimeter\n");
		scanf("%d",&ch);
		switch(ch)
		{	
		case 1:	
			printf("Enter the side of the square:\n");		
			scanf("%f",&s);
			ar=s*s;
			printf("\nArea:%f",ar);
			break;
		case 2:	
			printf("Enter the side of the square:\n");		
			scanf("%f",&a);
			pr=4*a;
			printf("\nPerimeter:%f",pr);
			break;			
			}
		}	
