/*Checking operator*/
#include<stdio.h>
void main()
{
int a,b;
a=10;
b=a<<2;
printf("%d",b);
}
