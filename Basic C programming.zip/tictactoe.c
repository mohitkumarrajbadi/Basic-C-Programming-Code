/*Code to create a Tic Tac Toe game*/

#include<stdio.h>
void display(char a[3][3]);
void main()
{
	char a[3][3];
	int i,j,count=1;
	for(i=0;i<3;i++){
	for(j=0;j<3;j++){
		a[i][j]=count;
		count++;	
		}
	}

display(a);		

while(1){
		int choice;
		printf("\nEnter your choice");
		scanf("%d",&choice);
		for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			if(a[i][j]==choice){
					a[i][j]='X';				
					}
			}		
		}	
	display(a);
	}
}

void display(char a[3][3]){
			int i,j;
			printf("_______________");
			for(i=0;i<3;i++){
			printf("\n");
			for(j=0;j<3;j++){
			printf("| %c |",a[i][j]);	
				}
			printf("\n");	
			printf("_______________");	
			}
		}
