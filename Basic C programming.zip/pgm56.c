/*Input Medicine_id,Medicine_Name,Brand_name,cost_price,sale_price,mfg_date,exp_date,sale_qty through structure .Calculate the Profit and Total Profit for the sale of 15 products.The date should be nested structure.Display all the records with profits and total profit*/

#include<stdio.h>
void main()
{
	struct product{
		long mid;
		char mname[20];
		char bname[10];
		float cp;
		float sp;
		int sq;
		struct date{
			int date;
			int year;
			int month;	
			}dt[15];
		}prod[15];
		int i;
	for(i=0;i<15;i++){	
	printf("\nEnter the Medicine Id : \n");
	scanf("%ld",&prod[i].mid);
	printf("Enter the name : \n");
	scanf("%s",prod[i].mname);
	printf("Enter the Brand Name : \n");
	scanf("%s",prod[i].bname);
	printf("Enter the Cost Price : \n");
	scanf("%f",&prod[i].cp);
	printf("Enter the Sell Price : \n");
	scanf("%f",&prod[i].sp);
	printf("Enter the Manfacturing Date (dd/mm/yyyy) : \n");
	scanf("%d/%d/%d",&prod[i].dt[i].date,&prod[i].dt[i].month,&prod[i].dt[i].year);
	printf("Enter the Expiry Date (dd/mm/yyyy) : \n");
	scanf("%d/%d/%d",&prod[i].dt[i+1].date,&prod[i].dt[i+1].month,&prod[i].dt[i+1].year);	
	printf("Enter the Sale Quantity : \n");
	scanf("%d",&prod[i].sq);	
		}
	
	

	for(i=0;i<15;i++){
	printf("\n\n\n");	
	printf("\nMedicine_Id : %ld \n",prod[i].mid);
	printf("\nMedicine_Name : %s \n",prod[i].mname);
	printf("\nBrand_Name : %s \n",prod[i].bname);

	printf("\nManfacturing Date : %d %d %d \n",prod[i].dt[i].date,prod[i].dt[i].month,prod[i].dt[i].year);
	printf("\nExpiry Date : %d %d %d \n",prod[i].dt[i+1].date,prod[i].dt[i+1].month,prod[i].dt[i+1].year);

	printf("\nCost_Price : %.2f \n",prod[i].cp);
	printf("\nSell_Price : %.2f \n",prod[i].sp);
	printf("\nSell_Quantity : %d \n",prod[i].sq);
	
	prod[i].cp=prod[i].cp*prod[i].sq;
	prod[i].sp=prod[i].sp*prod[i].sq;
	
	if(prod[i].cp<prod[i].sp)
		{
		printf("\nProfit of the Product is : %.2f",prod[i].sp-prod[i].cp);		
		}	
	else
		{
		printf("\nProfit of the Product is : No PROFIT !!!");
		}

	printf("\n");
	}
	
	float tcp=0,tsp=0;
	for(i=0;i<2;i++){
		tcp=tcp+prod[i].cp;
		tsp=tsp+prod[i].sp;
	}
	
	printf("\nTotal profit : %f \n",tsp-tcp);
}
