/*Program to input  student rollno,name,subjects,marks using structure.Display Total Marks & percentage & also details of the students*/
#include <stdio.h>
void main()
{
	struct student{
	int rollno;
	char name[20];
	int pm,nc,pc,bc,wd;
	}stud;
	printf(" \n Enter the Rollno: ");
	scanf("%d",&stud.rollno);
	printf(" \n Enter the Name:");
	scanf(" %s",stud.name);
	printf(" \n Enter the PM Marks:");
	scanf(" %d",&stud.pm);
	printf(" \n Enter the NC Marks:");
	scanf(" %d",&stud.nc);
	printf(" \n Enter the Pgrm.C Marks:");
	scanf(" %d",&stud.pc);
	printf(" \n Enter the BC Marks:");
	scanf(" %d",&stud.bc);
	printf(" \n Enter the WDP Marks:");
	scanf(" %d",&stud.wd);

	float sum=0;
	sum=stud.nc+stud.pc+stud.pm+stud.bc+stud.wd;
	float per=0;
	per=sum/250*100;
		printf("\n\n\n");
	printf("Name: %s\n",stud.name);
	printf("RollNo: %d\n",stud.rollno);
	printf("Total Marks: %f\n",sum);
	printf("Percentage: %f\n",per);
}
