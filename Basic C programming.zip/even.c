#include<stdio.h>
void main()
{
int a=1;
while(a++ <= 10 && a%2==0)
{
printf("Even number is:%d\n",a);
a++;
}
printf("Odd number is:%d\n",a);
}

