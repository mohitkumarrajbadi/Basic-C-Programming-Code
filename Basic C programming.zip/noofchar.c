#include<stdio.h>
void main()
{
char m[10],i;
printf("Enter the character:\n");
scanf("%s",m);
for(i=0;m[i]!='\0';i++);
printf("The number of character is:%d\n",i);
}
