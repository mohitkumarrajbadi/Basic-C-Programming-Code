/*Program to print the palindrome number within the range using function*/

#include<stdio.h>
int palindrome(int num);
void main()
{
int a,b,reverse;
printf("Enter the upper range and lower range:");
scanf("%d %d",&a,&b);
while(a<=b)
	{
	reverse = palindrome(a);
	if(reverse == a)
		{
		printf("%d\t",a);		
		}
	a=a+1;
	}
}

int palindrome(int num)
	{
	int rem=0,rev=0;
	while(num!=0)
		{
		rem=num%10;
		rev=rev*10+rem;
		num=num/10;	
		}
	return rev;
	}
