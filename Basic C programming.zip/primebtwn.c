#include<stdio.h>
void main()
{
	int i,j=100,prime=0;
	printf("Prime number are:\n");
       while(j<=300)
	{
       		for(i=j;i<=j/2;++i)
		{
		if(j%i==0)
			prime=1;
else prime=0;
		if (prime==0)
			printf("%d",j);		
	}
		}

	}

