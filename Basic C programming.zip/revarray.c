//Program to reverse an array or LIFO//

#include<stdio.h>
void main()
{
	int no[10],a;
	printf("Enter 10 number:\n");
	for(a=0;a<10;a++)
	{
	scanf("%d",&no[a]);
	}
	printf("The reverse of the array:\n");
	for(a=9;a>0;a--)
	{
	printf("%d\n",no[a]);
	}
}
