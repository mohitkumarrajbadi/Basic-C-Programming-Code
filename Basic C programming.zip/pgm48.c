/*Program to input 5 objects name and length in feet and inch .Calculate there their total length in feet & inch .Display the datails of all the objects and there total length in feet and inch*/

#include<stdio.h>
void main()
{
	struct obj{
	char name[10];	
	int feet;
	int inch;
	}a[5];
	int i;
	for(i=0;i<5;i++)
	{
	printf("Enter the Name : ");
	scanf("%s",a[i].name);
	printf("Enter the Feet : ");
	scanf(" %d",&a[i].feet);
	printf("Enter the Inch : ");
	scanf(" %d",&a[i].inch);
	}
	
	printf("\n\n\n");
	printf("Name\n");
	for(i=0;i<5;i++)
	{
	printf("%s\t",a[i].name);
	printf("%d\t",a[i].feet);
	printf("%d\t",a[i].inch);
	printf("\n");	
	}
	
	
	int tfeet=0,tinch=0,q;
	for(i=0;i<5;i++)
	{
	tfeet+=a[i].feet;
	tinch+=a[i].inch;
		if(tinch>=12)
		{
		q=tinch/12;
		tinch=tinch%12;
		tfeet=tfeet+q;	
		}
	}	

	printf("Total:\t%d\t%d\n",tfeet,tinch);
}
