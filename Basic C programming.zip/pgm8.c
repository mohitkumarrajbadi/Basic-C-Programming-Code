/*Program to perform arithmetic operation on 2 variables*/
#include<stdio.h>
void main()
{
int a,b,ans=0;
int smb;
printf("Enter the numbers:");
scanf("%d %d",&a,&b);
printf("ADDITION 1\n SUBTRACTION 2\n MULTIPLICATION 3\n DIVISION 4\n MODULUS 5\n");
scanf("%d",&smb);
switch(smb)
	{
	case 1:
		ans=a+b;
		printf("The addition of the number is %d\n",ans);
		break;
	case 2:
		ans=a-b;
		printf("The subtraction of the number is %d\n",ans);
		break;
	case 3:
		ans=a*b;
		printf("The multiplication of the number is %d\n",ans);
		break;	
	case 4:
		ans=a/b;
		printf("The division of the number is %d\n",ans);
		break;
	case 5:
		ans=a%b;
		printf("The reminder of the number is %d\n",ans);
		break;
	}
}
