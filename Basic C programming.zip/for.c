#include <stdio.h>
void main()
{
int a=1;
for(;printf("%d",a)-2;a++);
}
