/*Program to return the largest number using the function*/
#include<stdio.h>
int *large(int *a1,int *b1);
void main(){
	int a=10,b=20;
	int *p;
	p=large(&a,&b);
	printf("The largest number is : %d \n",*p);
	}
int *large(int *a1,int *b1){
	if(*a1>*b1){
		return (a1);		
		}
	else
		return (b1);
	}
