/*Program to enter two time and find their difference between them*/
#include<stdio.h>
void main()
{
int hh,mm,ss,hh2,mm2,ss2;
int rh,rm,rs;
printf("Enter the first time you want (HH:MM:SS):\n");
scanf("%d %d %d",&hh,&mm,&ss);
printf("Enter the second time you want (HH:MM:SS):\n");
scanf("%d %d %d",&hh2,&mm2,&ss2);
	if(ss>ss2)
		rs=ss-ss2;
	else
		{
		ss=ss+60;
		rs=ss-ss2;
		mm=mm-1;
		}
	if(mm>mm2)
		rm=mm-mm2;
	else
		{
		mm=mm+60;
		rm=mm-mm2;
		hh=hh-1;
		}
	if(hh>hh2)
		rh=hh-hh2;
	else
		{
		hh=hh+60;
		rh=hh-hh2;
		ss=ss-60;
		}
printf("The difference is:%d:%d:%d\n",rh,rm,rs);
}
