#include <stdio.h>
void main()
{
int a=1;
system ("clear");
area1:
 printf("a=%d",a);
 a++;
 goto area1;
 area2:
     printf("a=%d",a);
}
