/*Program to add and multiply the diagonal element of the matrix*/

#include<stdio.h>
void main()
{
int x,y;
printf("Enter the value of x and y: \n");
scanf("%d %d",&x,&y);

printf("Enter the elements in the array:\n");
int a[x][y],i,j,sum=0,sum1=0,mul=1,mul1=1;

for(i=0;i<x;i++)
	{
		for(j=0;j<y;j++)
			{
			scanf("%d",&a[i][j]);			
				}
		}


for(i=0;i<x;i++)
	{
		for(j=0;j<y;j++)
			{
			printf("%d\t",a[i][j]);			
				}
		printf("\n");
		}




for(i=0;i<x;i++)
		for(j=0;j<y;j++)
				if(i==j)
					sum=sum+a[i][j];					

for(i=x;i>=0;i++)
		for(j=y;j>=0;j++)
				if(i==j)
					sum1=sum1+a[i][j];					

printf("The sum of the diagonal of the element:%d and %d \n",sum,sum1);



for(i=0;i<x;i++)
for(j=0;j<y;j++)
	if(i==j)
		mul=mul+a[i][j];					


for(i=x;i>=0;i++)
	for(j=y;j>=0;j++)
		if(i==j)
		mul1=mul1+a[i][j];					
printf("The multiplication of the diagonal of the element:%d and %d \n",mul,mul1);


}
