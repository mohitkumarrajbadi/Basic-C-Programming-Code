//WAP to print odd or even number//

#include<stdio.h>
void main()
{
	int num;
	printf("Enter the number you wanted to check for even/odd:");
	scanf("%d",&num);
	if(num%2==0)
	printf("%d is the even number",num);
	else
	printf("%d is the odd number",num);
}
