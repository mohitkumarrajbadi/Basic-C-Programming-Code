/*Program to input Rollno,RegNo,Name,Branch Subject marks and generate a marksheet having all the above informations with total marks 
percent age and grade.Using if else and swith case to calculate grade in two separate program.*/
#include<stdio.h>
void main()
{
int rollno,i,marks[5],regno;
float percentage,totalmark=0;
char name[30],branch[10],grade;
printf("Enter your name:");
gets(name);
printf("Enter your Branch:");
gets(branch);
printf("Enter rollno:");
scanf("%d",&rollno);
printf("Enter you registration number:");
scanf("%d",&regno);
printf("Enter your marks in particular subjects:");	
	for(i=0;i<5;i++)
	{
	scanf("%d",&marks[i]);	
	}
	for(i=0;i<5;i++)
	{
	totalmark=totalmark+marks[i];
	}
	
	percentage=(float)(totalmark/250)*100;

printf("\nName:%s\n",name);
printf("Rollno:%d\n",rollno);
printf("Reg.no:%d\n",regno);
printf("Branch:%s\n",branch);
printf("\tFC:%d\n",marks[0]);
printf("\tPM:%d\n",marks[1]);
printf("\tMF:%d\n",marks[2]);
printf("\tEL:%d\n",marks[3]);
printf("\tDE:%d\n",marks[4]);
printf("\tTotal Marks:%f\n",totalmark);
printf("\tPercentage:%f\n",percentage);
	if(percentage>=90&&percentage<=100)
	grade='O';
	else if(percentage>=80&&percentage<=90)
	grade='E';
	else if(percentage>=70&&percentage<=80)
	grade='A';
	else if(percentage>=60&&percentage<=70)
	grade='B';
	else if(percentage>=50&&percentage<=60)
	grade='C';
	else if(percentage>=40&&percentage<=50)
	grade='D';
	else
	grade='F';
		switch(grade)
		{
		case 'O':printf("\tGrade: O\n");
			break;
		case 'E':printf("\tGrade: E\n");
			break;
		case 'A':printf("\tGrade: A\n");
			break;
		case 'B':printf("\tGrade: B\n");
			break;
		case 'C':printf("\tGrade: C\n");
			break;
		case 'D':printf("\tGrade: D\n");
			break;
		default:printf("\tGrade: F\n");
		}
}
