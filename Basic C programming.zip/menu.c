#include<stdio.h>
void main()
{
int sd=75,md=125,tea=50,coffee=75,bill=0,plates,choice;
printf("Enter your choice (1,2,3,4,5):");
scanf("%d",&choice)
switch(choice)
{
case 1:
printf("\nEnter no of plates you want:");
scanf("%d",&plates);
bill=sd*plates;
printf("You are requested to pay Rs:%d in the counter..THANK YOU FOR VISITING");
break;
case 2:
printf("\nEnter no of plates you want:");
scanf("%d",&plates);
bill=md*plates;
printf("You are requested to pay Rs:%d in the counter..THANK YOU FOR VISITING");
break;
case 3:
printf("\nEnter no of cups you want:");
scanf("%d",&plates);
bill=tea*plates;
printf("You are requested to pay Rs:%d in the counter..THANK YOU FOR VISITING");
break;
case 4:
printf("\nEnter no of cups you want:");
scanf("%d",&plates);
bill=coffee*plates;
printf("You are requested to pay Rs:%d in the counter..THANK YOU FOR VISITING");
break;
case 5:
bill=5;
printf("You are requested to pay Rs:%d in the counter..THANK YOU FOR VISITING");
break;
default:
printf("INVALID INPUT!!!!");
}
}
