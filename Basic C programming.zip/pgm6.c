#include<stdio.h>
void main()
{
	char name[50],gd,s;
	printf("Enter your name:");
	gets(name); //scanf("%s",name);
	fflush(stdin);
	printf("Gender(M/F):");
	gd=getchar(); //scanf("%c",&gd);
	fflush(stdin);
	printf("Maritual status:");
	s=getchar(); //scanf("%c",&s);
	if((gd=='m' || gd=='M'))
	{
		printf("Mr.,%s",name);
	}
	else 	if((gd=='f' || gd=='F'))
	{
		if ((s=='m' || s=='M'))
			printf("Mrs.%s",name);
		else
			printf("Miss.%s",name);
	}
}
