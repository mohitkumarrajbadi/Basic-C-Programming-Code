#include<stdio.h>
void main()
{
int a[2][2],b[2][2],c[2][2],i,j;
printf("Enter the elememts in matrix\n");
for(i=0;i<2;i++){
for(j=0;j<2;j++){
scanf("%d",&a[i][j]);
}
}
("print the elements in another matrix\n");
for(i=0;i<2;i++){
for(j=0;j<2;j++){
scanf("%d",&b[i][j]);
}
}
for(i=0;i<2;i++){
for(j=0;j<2;j++){
c[i][j]=a[i][j]+b[i][j];
}
}
for(i=0;i<2;i++){
for(j=0;j<2;j++){
printf("%d\t",c[i][j]);
}
printf("\n");
}
}
