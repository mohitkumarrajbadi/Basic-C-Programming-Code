/*Program to dynamically alloctae memory to input n number and find thier sum */

#include<stdio.h>
void main()
{
	int n,i,*ptr,sum=0;
	printf("Enter number of elements : ");
	scanf("%d",&n);

	ptr=(int*) malloc(n * sizeof(int));
	if(ptr == NULL)
	{
		printf("Out of memory!!");
		exit(0);
	}
	
	printf("Enter the elements of array : ");
	for(i=0;i<n;++i){
		scanf("%d",ptr+1);
		sum += *(ptr+i);
	}
	
	for(i=0;i<n;++i){
		printf("%d\n",*(ptr+i));
		}
	printf("Sum = %d \n",sum);
	free(ptr);
}
