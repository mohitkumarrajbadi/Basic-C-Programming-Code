//Program to Concadinate two string and store in third string//

#include<stdio.h>
void main()
{
	char s1[100],s2[100],s3[500];
	int i,j,pos;
	printf("Enter first string:\n");
		scanf("%s",s1);
	printf("Enter second string:\n");
		scanf("%s",s2);
	for(i=0;s1[i]!='\0';++i);
	pos=i;
	for(j=0;s2[j]!='\0';++j,++i)
	{
		s1[i]=s2[j];
	}
	s1[i]='\0';
	for(i=0;first[i]!='\0';++i)
	{
		third[i]=first[i];
	}
printf("After concatination:%s\n",s1);
}
