#include<stdio.h>
void main()
{
	int a;
	while((a*a*a)<1000)
	{
		printf("%d\t",a*a*a);				
		a++;
	}
}
