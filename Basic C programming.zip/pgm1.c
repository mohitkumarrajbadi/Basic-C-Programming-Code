/*Program to enter a number and find the sum of the digit*/
#include<stdio.h>
void main()
{
int num,rem,sum=0;
printf("Enter the number:");
scanf("%d",&num);
while(num!=0)
	{
	rem=num%10;
	sum=sum+rem;
	num=num/10;
	}
printf("The sum ofthe digit is:%d\n",sum);
}
