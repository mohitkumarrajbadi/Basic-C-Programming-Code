//Sorting the string in the ascending order//

#include<stdio.h>
void main()
{
	char ch[100];
	int i,j,len,temp;
	printf("Enter the string :\n");
	gets(ch);
	for(len=0;ch[len]!='\0';len++);
	for(i=0;i<len;i++)
	{
	for(j=0;j<(len-1);j++)	
	{
	if(ch[j]>ch[j+1])
	{
		temp=ch[j];
		ch[j]=ch[j+1];
		ch[j+1]=temp;	
	}
	}
	}
printf("Sorted list in ascending order:%s\n",ch);
}
