/* Program to find Amstrong number*/
#include<stdio.h>
#include<math.h>
void main()
{
int a,num,rem,power,sum,n;
printf("Enter the number :");
scanf("%d",&num);
a=num;
	while(a!=0)
	{
	a=a/10;
	n++;
	}

	while(a!=0)
	{
	rem=a%10;
	power=pow(rem,n);
	sum=sum+power;
	a=a/10;
	}

	if(sum == num)
	{
	printf("\nThe number is Armstrong number");
	}
	else
	{
	printf("\nThe number is not a Armstrong number");
	}
}
