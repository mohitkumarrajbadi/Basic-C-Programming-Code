#include<stdio.h>
void main()
{
	int a=1;
	for(;printf("a=%d\n",a)-5;a++);
}
