//Program to reverse an string//

#include<stdio.h>
void main()
{
	char m[10];
	int i,len;
	printf("Enter the char:\n");
	scanf("%s",m);
	for(len=0;m[len]!='\0';len++);
	for(i=len;i>=0;i--)
	{
	printf("%c",m[i]);
	}
	printf("\n");
}
