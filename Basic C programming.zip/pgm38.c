/*Program to transpode a matrix*/
#include<stdio.h>
void main()
{
int i,j,x,y;
printf("ENTER THE NUMBER OF THE ROW AND COLUMNS\n:");
scanf("%d %d",&x,&y);

int a[x][y];

printf("Enter the first array element:\n");
for(i=0;i<x;i++)
for(j=0;j<y;j++)
scanf("%d",&a[i][j]);

printf("The matrix is:\n");
for(i=0;i<x;i++)
	{
	for(j=0;j<y;j++)
	printf("%d\t",a[i][j]);
printf("\n");
}

		printf("The transpose matrix is:\n");
		for(i=0;i<x;i++)
			{
			for(j=0;j<y;j++)
			printf("%d\t",a[j][i]);
		printf("\n");
		}

}

