/*Program to perform matrix addition*/

#include<stdio.h>
void addition(int x[][3],int y[][3]);
void main()
	{
	int i,j;
	int a[3][3],b[3][3];

	printf("Enter the first array element:\n");
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
	scanf("%d",&a[i][j]);

	printf("Enter the second array element:\n");
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
	scanf("%d",&b[i][j]);
	addition(a,b);
	}


void addition(int x[][3],int y[][3]){
	int i,j,c[3][3];
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
	c[i][j]=x[i][j]+y[i][j];
	
	printf("THe matrix addition is:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
		printf("%d\t",c[i][j]);
		}
		printf("\n");
		}

	}
