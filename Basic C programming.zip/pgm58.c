/*Program to input dimensions (l,b,h) af two cuboid through structure and pass through function which will return the sum of (l,b,h)*/

#include<stdio.h>

struct dimension{
	int length;
	int height;
	int breadth;
	}c1,c2,c3,c4,*ptr;

struct dimension add(struct dimension c1,struct dimension c2){
	c4.length=c1.length+c2.length;
	c4.height=c1.height+c2.height;
	c4.breadth=c1.breadth+c2.breadth;
	return c4;
	}

void main(){	
	int i=0;
	printf("Enter the length of the first cuboid : ");
	scanf("%d",&c1.length);
	printf("Enter the height of the first cuboid : ");
	scanf("%d",&c1.height);
	printf("Enter the breadth of the first cuboid : ");
	scanf("%d",&c1.breadth);	


	printf("Enter the length of the second cuboid : ");
	scanf("%d",&c2.length);
	printf("Enter the height of the second cuboid : ");
	scanf("%d",&c2.height);
	printf("Enter the breadth of the second cuboid : ");
	scanf("%d",&c2.breadth);	


		
	c3=add(c1,c2);
	ptr=&c3;

	printf("\nThe sum of the length : %d \n",ptr->length);
	printf("\nThe sum of the length : %d \n",ptr->height);
	printf("\nThe sum of the length : %d \n",ptr->breadth);	
	}


