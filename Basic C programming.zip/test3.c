/*Program to perform operation using function*/

#include<stdio.h>
float addition(float a,float b);
float substraction(float a,float b);
float multiplication(float a,float b);
float division(float a,float b);
void main()
{
float x,y,ans;
int choice;
char ch='y';

while(ch=='y' || ch=='Y'){
printf("Enter the numbers:");
scanf("%f %f",&x,&y);
printf("Please enter your choice:\n1.Addition\n2.Substraction\n3.Multiplication\n4.Division");
scanf("%d",&choice);

	switch(choice){
		case 1:ans=addition(x,y);
			break;
		case 2:ans=substraction(x,y);
			break;
		case 3:ans=multiplication(x,y);
			break;
		case 4:ans=division(x,y);
			break;
		default:printf("Please enter the valid choice.\n");
		}
printf("\nThe answer is: %f",ans);
printf("\nDo you want to continue(y/n):");
scanf(" %c",&ch);
}
}


float addition(float a,float b){
		float sum;
		sum=a+b;
		return sum;
	}

float substraction(float a,float b){
		float sub;
		sub=a-b;
		return sub;
	}

float multiplication(float a,float b){
		float mul;
		mul=a*b;
		return mul;
	}

float division(float a,float b){
		float div;	
		div=a/b;
		return div;
	}
