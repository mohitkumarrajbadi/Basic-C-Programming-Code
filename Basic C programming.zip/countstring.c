//Program to calculate nos of words,vowels,consonants,digits and special character//

#include<stdio.h>
void main()
{
	char ch[100];
	int i,vowels=0,consonant=0,words=1,splchar=0,digit=0;
	printf("Enter the string you want to count:");
	gets(ch);
	for(i=0;ch[i]!='\0';i++)
	{
	if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||
	ch[i]=='U'||ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||
	ch[i]=='o'||ch[i]=='u')
	{
		vowels++;		
	}
	else if(ch[i]>'A'&&ch[i]<='Z'||ch[i]>'a'&&ch[i]<='z')
	{
		consonant++;
	}
	else if(ch[i]>='0' && ch[i]<='9')
	{
		digit++;
	}
	else if(ch[i]=' ')
	{
		words++;	
	}
	else
	{
		splchar++;
	}
	}
printf("The no of word is %d\n",words);
printf("The no of digit is %d\n",digit);
printf("The no of vowels is %d\n",vowels);
printf("The no of constants is %d\n",consonant);
printf("The no of special character is %d\n",splchar);	
}
