/*Program to Add array element using the pointer*/
#include<stdio.h>
void main()
{
int *p,i;
int sum=0;
int x[5]={1,2,3,4,5};
i=0;
p=x;
for(i=0;i<5;i++){
	//printf(" x[%d] : %d\n",i,*p);
	sum=sum + *p;
	p++;
	}

printf("\nThe sum of the Array Element is : %d\n",sum);
}
