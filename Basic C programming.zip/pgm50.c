/*Program to search employee details*/

#include<stdio.h>
void main()
{
struct details{
	long empid;
	char name[25];
	char deg[10];
	long salary;
	long mobile;
	char gender;
	char doj[10];
	char dob[10];	
	}emp[2];

	int i;
	for(i=0;i<2;i++)
	{
	printf("Enter the Employee Id : \n");
	scanf("%ld",&emp[i].empid);
	printf("Enter the name of the employee : \n");
	scanf("%s",emp[i].name);
	printf("Enter designation of the employee : \n");
	scanf("%s",emp[i].deg);
	
	printf("Enter salary of the employee : \n");
	scanf("%ld",&emp[i].salary);
	
	printf("Enter mobile number of the employee : \n");
	scanf("%ld",&emp[i].mobile);

	printf("Enter gender of the employee(M/F) : \n");
	scanf(" %c",&emp[i].gender);

	printf("Enter Date of Joining of the employee (dd/mm/yyyy) : \n");
	scanf("%s",emp[i].doj);
	printf("Enter Date of Birth of the employee (dd/mm/yyyy) : \n");
	scanf("%s",emp[i].dob);
	}

	char choice='y';
		while(choice=='y' || choice=='Y')
		{
		long id;
		int pos=0,flag=0;
		printf("\n Enter the Employee Id to be searched :");
		scanf("%ld",&id);
			for(i=0;i<2;i++)
			{
				if(emp[i].empid==id)
					{
					flag=1;
					pos=i;					
						}					
					}
					
			if(flag==1){
				printf("\nEmployee ID : %ld \n",emp[pos].empid);	
				printf("Name : %s \n",emp[pos].name);
				printf("Designation : %s \n",emp[pos].deg);
				printf("Salary : %ld \n",emp[pos].salary);
				printf("Mobile Number : %ld \n",emp[pos].mobile);
				printf("Gender : %c \n",emp[pos].gender);
				printf("Date of Joining (dd/mm/yyyy): %s \n",emp[pos].doj);
				printf("Date of Date of Birth (dd/mm/yyyy): %s \n",emp[pos].dob);					
				}
			else
			printf("\n Employee Not Found !!!!\n ");									
			
			printf("\nDo you want to continue:(Y/N)\n");
			scanf("%c",&choice);		
			}
		
}
