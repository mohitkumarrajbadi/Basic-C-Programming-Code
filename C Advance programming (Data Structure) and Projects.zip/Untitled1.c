/*Program to print the greatest number in an array*/
#include<stdio.h>
void main()
{
	int ar[10],greatest,i;
	printf("Enter the number in the array:");
	for(i=0;i<10;i++)
	{
		scanf("%d",&ar);
	}
	
	greatest=ar[0];
	for(i=1;i<10;i++)
	{
		if(ar[i]>greatest)
			greatest=ar[i];
	}
	printf("Greatest is:%d",greatest);
}

