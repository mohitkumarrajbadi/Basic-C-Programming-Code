#include<stdio.h>
#include<stdlib.h>
struct num{
	int a,b,c;
};
void main()
{
	struct num n;
	FILE *fp;
	fp=fopen("mohit.bin","wb");
	if(fp==NULL){
		printf("Error to open the file!!");
		exit(1);
	}
	printf("Enter the value of a :");
	scanf("%d",&n.a);
	printf("Enter the value of b :");
	scanf("%d",&n.b);
	printf("Enter the value of c :");
	scanf("%d",&n.c);
	fwrite(&n,sizeof(struct num),1,fp);
	fclose(fp);
	
	fp=fopen("mohit.bin","rb");
	if(fp==NULL){
		printf("Error to open the file!!");
		exit(1);
	}
	fread(&n,sizeof(struct num),1,fp);
	printf("a:%d \n b:%d \n c:%d \n",n.a,n.b,n.c);
	fclose(fp);
}
