#include<stdio.h>

int top = -1;

void push(char stack[],char infix){
	
	top++;
	stack[top] = infix;
	
}


char pop(char stack[]){
	
	if(top != -1){
		return stack[top--];
	}else{
		return 0;
	}
	
	
}

int priority(char c){
	if(c == '+' || c == '-'){
		return 1;
	}
	else if(c == '*' || c == '/'){
		return 2;
	}
	else if(c == '^'){
		return 3;
	}
	else{
		return 0;
	}
}

main(){
	
	char stack[20];	
	char infix[20];
	char postfix[20];
	int i;
	
	printf("Enter the infix operation :");
	scanf("%s",infix);
	i=0;
	while(infix[i] != NULL){
		
		if(infix[i] == '{' || infix[i] == '[' || infix[i] == '('){
			push(stack,infix[i]);	
		}else if(infix[i] == '}' || infix[i] == ']' || infix[i] == ')'){
				while(infix[i] == '{' || infix[i] == '[' || infix[i] == '('){
					postfix[i] = pop(stack);
				}
		}else if(infix[i] == '+' || infix[i] == '-' || infix[i] == '/' || infix[i] == '*' || infix[i] == '%' || infix[i] == '^'){
			if(priority(infix[i]) >= priority(top)){
				push(stack,infix[i]);	
			}else{
				while(priority(infix[i]) >= priority(top)){
					if(top != -1){
						postfix[i] = pop(stack);
					}				
				}	
			}					
		}else{
			postfix[i] = infix[i];
		}
		
		while(top != -1){
			postfix[i] = pop(stack); 
		}
		
		i++;	
		}
		
		
		printf("\nThe postfix of the stack is : \n%s\n",postfix);
		
		
	}
	

