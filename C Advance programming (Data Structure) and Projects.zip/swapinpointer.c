#include<stdio.h>
void swap(int *n1,int *n2);
void main()
{
	int num1=5,num2=10;
	printf("\n%x",&num1);
	printf("\n%x\n",&num2);
	swap(&num1,&num2);
	printf("Number1=%d\n",num1);
	printf("Number2=%d\n",num2);
}
void swap(int *n1,int *n2){
	printf("\n%x",n1);
	printf("\n%x\n",n2);
	int *temp;
	temp=n1;
	n1=n2;
	n2=temp;
	printf("\n%x",n1);
	printf("\n%x\n",n2);
}
