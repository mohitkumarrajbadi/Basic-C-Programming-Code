#include<stdio.h>
main(){
int n;
char ch;
while(ch!='n')
{
   printf("Enter the number upto which you want the sum of \n \n");
   scanf("%d",&n);
	int i=1;
	int j=0;
   while(i<=n)
   {

      j=j+i;
      i++;

   } 
   printf("%d \n",j);
   printf("Do it with another number? Y/N \n \n");
   scanf("%c",&ch);
}
return 0;
}
