#include<stdio.h>
#include<stdlib.h>
#define maxsize 4
int front = -1,rear = -1;

int isFull(){
	if(rear == maxsize - 1)
		return 1;
	else
		return 0;
}

int isEmpty(){
	if(front == -1 && rear == -1)
		return 1;
	else
		return 0;
}

int Delete(int queue[]){
	int temp;
	temp = queue[front];
	if(front == rear){
		front = -1; 
		rear = -1;
	}else{
		front++;
	}
	return temp;
}

int read(int queue[]){
	return queue[front];
}

void insert(int queue[],int element){	
	if(front == -1 && rear == -1){
		front = 0; 
		rear = 0;
	}else{
		rear++;
	}
	queue[rear] = element;	
}


main(){

	int queue[maxsize],choice;
	
	do{	
		printf("QUEUE Operation\n");
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Read\n");
		printf("4.Exit\n");
		printf("Enter your choice [1-4]: ");
		scanf("%d",&choice);
		switch(choice){
			case 1:
				if(isFull()){
					printf("Queue Overflow\n");
				}
				else{
					int element = 0;
					printf("\nEnter the element you want to insert : ");
					scanf("%d",&element);
					insert(queue,element);
				}
				break;
			case 2:
				if(!isEmpty()){
					printf("%d Deleted from the queue\n",Delete(queue));
				}else{
					printf("Queue Underflow\n");
				}
				break;
			case 3:
				if(!isEmpty()){
					printf("%d read\n",read(queue));
				}else{
					printf("Queue Underflow\n");
				}
				break;
			case 4:
				exit(1);
				break;
			default:
				printf("\nInvalid Input!!\n");
		}
	}while(1);

	
	
}
