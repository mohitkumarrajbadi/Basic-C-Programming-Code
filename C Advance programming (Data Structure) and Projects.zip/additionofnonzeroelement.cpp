#include<stdio.h>

int addingNonzero(int martix[3][3]){
	
	
	int sum = 0,i,j;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
		
		if(matrix[i][j] != 0){
			
			sum = sum + martix[i][j];
			
			}
		}
	}
	
	return sum;
	
}



void main(){
	
	int matrix[3][3],sum = 0,i,j;
	
	printf("Enter the element in the matrix");
	
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			
			scanf("%d",&matrix[i][j]);
			
		}
	}
	
 sum = addingNonzero(martix);	
	
	printf("The sum of the non-zero element on the array : %d",sum);
		
}
