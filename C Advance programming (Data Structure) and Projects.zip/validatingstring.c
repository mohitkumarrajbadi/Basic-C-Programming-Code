#include<stdio.h>
void main(){
	
	char string[20];
	int i;
	
	printf("Enter the string : ");
	gets(string);
	
	for(i=0;string[i] != '\0';i++){
		if(string[i]>=97 && string[i]<=122 || string[i]>=65 && string[i]<=90){
			printf("%c\n",string[i]);
		}
	}
	
	
}
