#include<stdio.h>

int top = -1;

void push(char stack[],char infix){
	
	top++;
	stack[top] = infix;
	
}


char pop(char stack[]){
	
	if(top != -1){
		return stack[top--];
	}else{
		printf("stack underflow");
	}
	
	
}

int priority(char c){
	if(c == '+' || c == '-'){
		return 1;
	}
	else if(c == '*' || c == '/'){
		return 2;
	}
	else if(c == '^'){
		return 3;
	}else{
		return 0;
	}
	
}

main(){
	
	char stack[20];	
	char infix[20];
	int i;
	
	printf("Enter the infix operation :");
	scanf("%s",infix);
	i=0;
	while(infix[i] != '\0'){
		
		if(infix[i] == '('){
			push(stack,infix[i]);	
		}
	else if(infix[i] == ')'){
				while(stack[top] != '('){
				printf("%c",pop(stack));
				}
				if(stack[top] == '('){
					pop(stack);
				}
				
		}
		else if(infix[i] == '+' || infix[i] == '-' || infix[i] == '/' || infix[i] == '*'  || infix[i] == '^'){
				while(priority(infix[i]) <= priority(stack[top])){
						 printf("%c",pop(stack));
					}
				push(stack, infix[i]);					
				}	
								
		else{
			printf("%c",infix[i]);
		}
		
		i++;	
		}
		
		while(top != -1){
			printf("%c",pop(stack)); 
		}
		
	}
	

