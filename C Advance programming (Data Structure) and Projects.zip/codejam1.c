#include<stdio.h>
#include<math.h>



void main(){
	
	int test;
	
	scanf("%d",&test);
	
	long n[test],o[test],d[test];
	long x1[test],x2[test],a[test],b[test],c[test],m[test],l[test];
	
	int i;
	
	long x[20],s[20];
	
	
	for(i=0;i<test;i++){
		
		scanf("%ld%ld%ld",&n[i],&o[i],&d[i]);
		scanf("%ld%ld%ld%ld%ld%ld%ld",&x1[i],&x2[i],&a[i],&b[i],&c[i],&m[i],&l[i]);
	
	}
	
	for(i=0;i<test;i++){
	
		x[i]=x[n[i]];
		s[i]=s[n[i]];
		
		int j;
		for(j=3;j<=n[i];j++){
			x[j] = ((a[j] * x[j-1] + b[j-2]*x[j]+c[j] ) % m[j]);
		}
		
		for(j=0;j<n[i];j++){
			s[j] = x[j]+l[j];
		}
	}
	
	
	
	
	
	
	
	for(i=0;i<test;i++){
		
	if(test<=100 && test>=1 && 2 <= n[i] && n[i] <= (5*pow(10,5)) && 0<=o[i] && o[i]<=n[i] && pow(-10,5)<=d[i] && d[i]<=pow(10,5) && 0<=x1[i] && 0<=x2[i] && 0<=a[i] && 0<=b[i] && c[i] <= pow(10,9) && 1<=m[i] && m[i] <= pow(10,9)){
		
		long sum=0,higestodd = 0,higesteven = 2;
		
		for(i=0;i<n[i];i++){
			
			if(s[i]%2 != 0){
				if(s[i] > higestodd){
					higestodd=s[i];
				}
			}
			else{
				if(s[i] > higesteven){
					higesteven=s[i];
				}
			}
			
		}
		
		sum = higesteven+higestodd;
		
		printf("Case #%d : %ld",i+1,sum);	
			
	}
		
		else{
			printf("Case #%d : IMPOSSIBLE",i+1);
		}
		
		
		}
	}
	
