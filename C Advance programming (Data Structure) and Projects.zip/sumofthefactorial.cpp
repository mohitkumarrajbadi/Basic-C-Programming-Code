#include<stdio.h>
main()
{
	int n,i,sum=0,j,fact=1;
	printf("Enter the number :");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		fact=1;
		for(j=1;j<=i;j++){
			fact=fact*j;
		}
		sum=sum+fact;		
	}
		
	printf("Factorial of the number is : %d",fact);
	printf("\nThe sum of the factorial is: %d",sum);
}
