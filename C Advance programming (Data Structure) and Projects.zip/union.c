#include<stdio.h>
union mohit{
	long a;
	char b;
}m;

	void main(){
		
		m.a=12345;
		m.b='a';
		
		printf("The address of number is : %d \n",&m.a);
		printf("The address character is : %d \n",&m.b);
		
		printf("The number is : %ld \n",m.a);
		printf("The character is : %c \n",m.b);
		
		}
