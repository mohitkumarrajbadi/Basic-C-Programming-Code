#include<stdio.h>
void main()
{
	unsigned int i=0;
	for(i<=5&&i>=-1;++i;i>0)
	printf("%u,",i);
	
}
