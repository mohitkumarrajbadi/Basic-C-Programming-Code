#include<stdio.h>

void mergeTwoArray(int A[5],int B[5],int C[10],int m,int n){
	
	int i,j,k = 0;
	for(i=0;i<=(m-1);i++){
		C[k++] = A[i];
	}
	for(j=0;j<(n-1);j++){
		C[k++] = B[j];
	}
	
}


void main(){
	
	int A[5],B[5],C[10],m,n,i;
	printf("Enter the size of the array A and B : \n");
	scanf("%d %d",&m,&n);
	
	printf("Enter the %d numbers of element in the array A : \n",m);
	for(i=0;i<=(m-1);i++){
		scanf("%d",&A[i]);
	}
	
	printf("Enter the %d numbers of element in the array B : \n",n);
	for(i=0;i<=(n-1);i++){
		scanf("%d",&B[i]);
	}
	
	mergeTwoArray(A,B,C,m,n);
	
	printf("The merged array is : \n");
	for(i=0;i<=(m+n-1);i++){
		printf("%d\n",C[i]);
	}
	
}
