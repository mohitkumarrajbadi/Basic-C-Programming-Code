/*Project on School Management System
By-Mohit Kumar Raj Badi*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct student{
	char name[30];
	long rollno;
	int class;
	char fname[30];
	char mname[30];
	char address[50];
	};

void append();
void display();
void displayAll();
void modify();
void del();
void search();
void class();

char mygetch();

char fname[]={"mydb.txt"};

	int main()
		{
			int ch;

			while(1)
			{
			system("clear"); 

			printf("==================Student Management System=============\n\n");

			printf("1. Add Student\n\n");
			printf("2. Modify Student Data\n\n");
			printf("3. Delete Student Data\n\n");
			printf("4. Search Student Data\n\n");
			printf("5. Display Student Data\n\n");
			printf("6. Display All \n\n");
			printf("7. Display Student According to class\n\n");
			printf("0. Exit\n\n");

			printf("========================================================\n\n");

			printf("\nPlease enter your Choice:");
			scanf("%d",&ch);

			switch(ch)
			{
			case 1: append();
			break;

			case 2: modify();
			break;
	
			case 3: del();
			break;

			case 4: search();
			break;

			case 5: display();
			break;

			case 6: displayAll();
			break;
			
			case 7: class();
			break;

			case 0: exit(0);
			}

			mygetch();
			}

	return 0;
}





	//Modifiying the student data//
	

		void modify()
			{
				FILE *fp,*fp1;
				struct student t,t1;
				int found=0,count=0;
				long roll;							
				
				fp=fopen(fname,"rb");
				fp1=fopen("temp","wb");

				printf("\nEnter the Roll No you want to Modify:");
				scanf("%ld",&roll);

				while(1)
				{
				fread(&t,sizeof(t),1,fp);

				if(feof(fp))
				{
				break;
				}
				if(t.rollno==roll)
				{
				found=1;

				fflush(stdin);
				printf("\nEnter Student name:");
				scanf("%s",t.name);

				printf("\nEnter Rollno:");
				scanf("%ld",&t.rollno);
	
				printf("\nEnter class:");
				scanf("%d",&t.class);
		
				printf("\nEnter Student Father Name:");
				scanf("%s",t.fname);

				printf("\nEnter Student Mother Name:");
				scanf("%s",t.mname);

				printf("\nEnter Student Address:");
				scanf("%s",t.address);
				fwrite(&t,sizeof(t),1,fp1);
				}
				else
				{
				fwrite(&t,sizeof(t),1,fp1);
				}
				}
				fclose(fp);
				fclose(fp1);

				if(found==0)
				{
				printf("Sorry No Record Found\n\n");
				}
				else
				{
				fp=fopen(fname,"wb");
				fp1=fopen("temp","rb");

				while(1)
				{
				fread(&t,sizeof(t),1,fp1);

				if(feof(fp1))
				{
				break;
				}
				fwrite(&t,sizeof(t),1,fp);
				}

				}
				fclose(fp);
				fclose(fp1);
			}






			//Searching Student Data//
				void search()
				{
						FILE *fp;
						struct student t;
						int found=0;
						char name[20];

						fp=fopen(fname,"rb");

						printf("\nEnter the Student Name:");
						scanf("%s",name);

						while(1)
						{
						fread(&t,sizeof(t),1,fp);

						if(feof(fp))
						{
						break;
						}
						if(strcmp(name,t.name)==0)
						{
						printf("\n========================================================\n\n");
						printf("\t\t Student Details of %ld\n\n",t.rollno);
						printf("========================================================\n\n");
				
						printf("Name : %s\n",t.name);
						printf("Class : %d\n",t.class);
						printf("Father Name : %s\n",t.fname);
						printf("Mother Name : %s\n",t.mname);
						printf("Address : %s\n\n\n",t.address);
				

						printf("========================================================\n\n");

						}
						}
						if(found==0)
						{
						printf("\nSorry No Record Found");
						}
						fclose(fp);
				}




			//Delete the Student Data//
			
				void del()
					{
						FILE *fp,*fp1;
						struct student t,t1;
						int found=0,count=0;
						long roll;				
												
						fp=fopen(fname,"rb");
						fp1=fopen("temp.bin","wb");

						printf("\nEnter the Rollno you want to Delete:");
						scanf("%ld",&roll);

						while(1)
						{
						fread(&t,sizeof(t),1,fp);

						if(feof(fp))
						{
						break;
						}
						if(t.rollno==roll)
						{
						found=1;
						}
						else
						{
						fwrite(&t,sizeof(t),1,fp1);
						}
						}
						fclose(fp);
						fclose(fp1);

						if(found==0)
						{
						printf("Sorry No Record Found\n\n");
						}
						else
						{
						fp=fopen(fname,"wb");
						fp1=fopen("temp.bin","rb");

						while(1)
						{
						fread(&t,sizeof(t),1,fp1);

						if(feof(fp1))
						{
						break;
						}
						fwrite(&t,sizeof(t),1,fp);
						}
						}
						fclose(fp);
						fclose(fp1);
					}















		//Adding new student info//
				void append(){
	
					FILE *fp;
					struct student t1;

					fp=fopen(fname,"ab");

		
					printf("\nEnter Student name:");
					scanf("%s",t1.name);

					printf("\nEnter Rollno:");
					scanf("%ld",&t1.rollno);
	
					printf("\nEnter class:");
					scanf("%d",&t1.class);
		
					printf("\nEnter Student Father Name:");
					scanf("%s",t1.fname);

					printf("\nEnter Student Mother Name:");
					scanf("%s",t1.mname);

					printf("\nEnter Student Address:");
					scanf("%s",t1.address);
	
					fwrite(&t1,sizeof(t1),1,fp);
		
					fclose(fp);
					}




	//Display the particular student by Name//
		
		void display()
			{
				FILE *fp;
				struct student t;
				int found=0;
				long roll;					
				
				fp=fopen(fname,"rb");

				printf("\nEnter the Roll No:");
				scanf("%ld",&roll);

				while(1)
				{
				fread(&t,sizeof(t),1,fp);

				if(feof(fp))
				{
				break;
				}
				if(t.rollno==roll)
				{
				found=1;
				printf("\n========================================================\n\n");
				printf("\t\t Student Details of Roll No : %ld\n\n",t.rollno);
				printf("========================================================\n\n");

				printf("Name : %s\n",t.name);
				printf("Class : %d\n",t.class);
				printf("Father Name : %s\n",t.fname);
				printf("Mother Name : %s\n",t.mname);
				printf("Address : %s\n\n\n",t.address);
		

				printf("========================================================\n\n");
				}
				}
				if(found==0)
				{
				printf("\nSorry No Record Found");
				}
				fclose(fp);	
			}





		


	//Display the all the student data entered//

			void displayAll()
			{
				FILE *fp;
				struct student t;

				fp=fopen(fname,"rb");

				printf("\n========================================================\n\n");
				printf("\t\t All Student Details\n\n");
				printf("========================================================\n\n");

				while(1)
				{
				fread(&t,sizeof(t),1,fp);

				if(feof(fp))
				{
				break;
				}
				printf("RollNo : %ld\n",t.rollno);
				printf("Name : %s\n",t.name);
				printf("Class : %d\n",t.class);
				printf("Father Name : %s\n",t.fname);
				printf("Mother Name : %s\n",t.mname);
				printf("Address : %s\n\n\n",t.address);

				}
				printf("========================================================\n\n");

				fclose(fp);
				}

		
	//Display Student According to the class//

				void class(){
						FILE *fp;
						struct student t;
						int found=0;
						int cl;					
				
						fp=fopen(fname,"rb");

						printf("\nEnter the Class:");
						scanf("%d",&cl);

						printf("\n========================================================\n\n");
						printf("\t\t Student Details of class : %d\n\n",cl);
						printf("========================================================\n\n");
						while(1)
						{
							fread(&t,sizeof(t),1,fp);

							if(feof(fp))
							{
							break;
							}
						
						if(t.class==cl)
						{
						found=1;
						
						printf("Name : %s\n",t.name);
						printf("Class : %d\n",t.class);
						printf("Father Name : %s\n",t.fname);
						printf("Mother Name : %s\n",t.mname);
						printf("Address : %s\n\n\n",t.address);
		
						}
						}
						
						if(found==0)
						{
						printf("\nSorry No Record Found");
						}
						printf("========================================================\n\n");
						fclose(fp);
					}


	char mygetch()
			{
				char val;
				char rel;

				scanf("%c",&val);
				scanf("%c",&rel);
				return (val);
			}








