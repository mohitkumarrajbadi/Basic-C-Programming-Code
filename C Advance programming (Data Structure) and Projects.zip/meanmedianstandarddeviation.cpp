#include<stdio.h>
#include<math.h>


float standard_deviation_function(int array[],int size,float mean){
	
	int i;
	float standard_deviation_value;
	
	for(i=0;i<size;i++){
		
		standard_deviation_value += pow(array[i] - mean,2); 
		
	}
	
	return sqrt(standard_deviation_value/size); 
	
}





float median_function(int array[],int size){
	
	float median_value;
	int i, j, temp = 0;
	
    for(i=0; i<size-1; i++) {
        for(j=i+1; j<size; j++) {
            if(array[j] < array[i]) {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
    }
	
	
	
	if(size%2 == 0){
		
		median_value = (array[size/2] + array[size/2 + 1]);
		
		median_value /= 2;
		
	}else{
		
		median_value = array[(size+1)/2];
		
	}
	
	return median_value;
	
}




float mean_function(int array[],int size){
	
	int i;
	float mean_value = 0;
	
	for(i=0;i<size;i++){
		mean_value = mean_value + array[i];
	}
	
	mean_value /= size;
	
	return mean_value;
	
}


main(){

int array[10];
int size,i;
float mean,median,standard_deviation;

printf("Enter the size of the Array : ");
scanf("%d",&size);

printf("Enter the element in the array : ");
for(i=0;i<size;i++){
	
	scanf("%d",&array[i]);

	}
	
	mean = mean_function(array,size);
	
	median = median_function(array,size);
	
	standard_deviation = standard_deviation_function(array,size,mean);
	
	
	printf("Mean : %.2f \n",mean);
	printf("Median : %.2f \n",median);
	printf("Standard Deviation : %.2f \n",standard_deviation);
	
}
