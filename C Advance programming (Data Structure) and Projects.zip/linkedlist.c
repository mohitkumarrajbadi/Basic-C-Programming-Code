#include<stdio.h>
#include<stdlib.h>

struct node{
	int info;
	struct node * next;
};

void insertatbegin(struct node **head, int element){
	
	struct node * newnode;
	newnode = (struct node *)malloc(sizeof(struct node));
	newnode -> info = element;
	newnode -> next = NULL;
	if(*head == NULL){
		*head = newnode; 
	}else{
		newnode -> next = *head;
		*head = newnode; 
	}
	
}


void insertatend(struct node **head, int element){
	
	struct node * newnode,*temp;
	newnode = (struct node *)malloc(sizeof(struct node));
	newnode -> info = element;
	newnode -> next = NULL;
	if(*head == NULL){
		*head = newnode;	 
	}else{
		temp = *head;
		while(temp -> next != NULL){
			temp = temp -> next;
		}
		temp -> next = newnode;
	}
	
}


void insertatposition(struct node **head,int element,int position){
	
	int count;
	struct node * temp;
	temp = *head;
	
	struct node * newnode;
	newnode = (struct node *)malloc(sizeof(struct node));
	newnode -> info = element;
	newnode -> next = NULL;
	
	while(temp != NULL){
		count++;
		temp = temp->next;
	}
	if(position < 1 || position > count + 1 ){
		printf("The newnode to be inserted must greatest than or equal to the first position\nEnter the a valid position \n");
		return;
	}else{
		if(position == 1){
			insertatbegin(head,element);
		}else if(position > count){
			insertatend(head,element);
		}else{
				int pos = 0;
				temp = *head;
				while(temp!=NULL){
					pos++;
					if(pos == position - 1){
						newnode->next = temp->next;
						temp ->next = newnode;
						return;
					}
					temp = temp -> next;
				}
		}
	}
		
}



void deletebegin(struct node **head){
	
	struct node * temp = * head;
	
	if(temp == NULL){
		printf("Please insert some Node in the linked list then come to delete!!\nBluddy Foolish person\n");
	}else{
		temp = temp -> next;
	}
	*head = temp;
}

void deleteend(struct node **head){
	
	struct node * temp = *head;	
	if(temp == NULL){
		printf("Please insert some Node in the linked list then come to delete!!\nBluddy Foolish person\n");
	}else{
		if(temp->next != NULL){
			while(temp->next->next != NULL){
				temp = temp->next;
			}
			temp -> next = NULL;
		}else{
			*head = NULL;
		}
	}
	
}



void deleteposition(struct node ** head,int position){
	
	int count;
	struct node * temp;
	temp = *head;
	
	while(temp != NULL){
		count++;
		temp = temp->next;
	}
	
	if(position == 1){
		deletebegin(head);
	}else if(position > count){
		printf("Impossible to Delete Foolish!!\n");
	}else if(position == count){
		deleteend(head);
	}else{
				int pos = 0;
				temp = *head;
				while(temp!=NULL){
					pos++;
					if(pos == position - 1){
						temp -> next = temp -> next -> next;
						return;
					}
					temp = temp -> next;
				}
	}	
}



void display(struct node * head){
	int i = 0;
	if (head == NULL){
		printf("\nThe linked List is Empty \nCreate some Node \n\n");
		return;
	}else{
		while(head != NULL){
		printf("%d.Info:%d\n",++i,head->info);
		head = head->next;
		}
	}
}

void main(){
	int choice,element,position;
	struct node * head = NULL;
	do{
		printf("\nLinked List Operation \n");
		printf("1.Insert at the begining\n");
		printf("2.Insert at the end\n");
		printf("3.Insert at the position\n");
		printf("4.Delete at the begining\n");
		printf("5.Delete at the end\n");
		printf("6.Delete at the position\n");
		printf("7.Display linked list\n");
		printf("8.Exit\n");
		printf("Enter yout choice : ");
		scanf("%d",&choice);
		switch(choice){
			case 1:printf("Enter the element : ");
				scanf("%d",&element);
				insertatbegin(&head,element);
				break;
			case 2:printf("Enter the element : ");
				scanf("%d",&element);
				insertatend(&head,element); 
				break;
			case 3:printf("Enter the element : ");
				scanf("%d",&element);
				printf("Enter the position : ");
				scanf("%d",&position);
				insertatposition(&head,element,position);
				break;
			case 4:deletebegin(&head);
				break;
			case 5:deleteend(&head);
				break;
			case 6:printf("Enter the position : ");
				scanf("%d",&position);
				deleteposition(&head,position);
				break;
			case 7:display(head);
				break;
			case 8: exit(1);
				break;
			default: printf("Invalid Input !\n");
		}
	}while(1);
}
