#include<stdio.h>

void towerofhanoi(int n,char beg,char end,char aux){
	if(n == 1){
		printf("Move a disk from %c to %c\n",beg,end);
	}else{
		towerofhanoi(n-1,beg,end,aux);
		printf("Move a disk from %c to %c\n",beg,aux);
		towerofhanoi(n-1,aux,beg,end);
	}
}

main(){
	towerofhanoi(3,'A','B','C');
}
