/*program to display all prime number between two interval*/
#include<stdio.h>
void main()
{
	int a,b,flag=0,i,j;
	printf("enter the interval: ");
	scanf("%d %d",&a,&b);
	for(j=a;j<=b;j++)
		{
		for(i=2;i<=j/2;a++)
		{
		if(j%i==0)
		flag=1;}
		if(flag==0)
		printf("%d\n",j);
		}
	
}
