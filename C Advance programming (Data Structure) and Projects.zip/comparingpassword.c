#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char pass[10]; //max length of the string;
    do{
        printf("enter your password: \n");
        scanf("%s",pass);
    }while(strcmp(pass,"*") != 0); //checks if strings are equal

    printf("%s",pass);


}
