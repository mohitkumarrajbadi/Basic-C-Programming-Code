#include<stdio.h>
void merge(int a[],int b[],int c[],int m,int n);
void main(){
	
	int a[4],b[5],c[9],m = 4,n = 5,i;
	
	printf("Enter the element in the first array : ");
	for(i=0;i<m;i++){
		scanf("%d",&a[i]);
	}
	
	printf("Enter the element in the second array : ");
	for(i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	
	merge(a,b,c,m,n);
	
	printf("\nThe sorted merged element : \n");
	for(i=0;i<n;i++){
		printf("%d\t",c[i]);
	}
	
	
}

void merge(int a[],int b[],int c[],int m,int n){
	
	int i = 0,j = 0,k=0;
	
	while(i <= m && j <= n){
		if(a[i]<b[j]){
			c[k++] = a[i++];
		}
		else{
			c[k++] = b[j++];
		}
	}
	
	while(i<=m){
		c[k++] = a[i++];
	}
	
	while(j<=n){
		c[k++] = b[j++];
	}
	
}
