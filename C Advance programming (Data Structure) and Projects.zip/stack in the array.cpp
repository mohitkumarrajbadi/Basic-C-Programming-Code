#include <stdio.h>
#include<iostream>
#define maxSize 4

using namespace std;

int stack[maxSize];
int top = -1;

int isEmpty();
void push(int number);
void pop();
void peep();

int main(){
	
	int choice;
	printf("\nStack Operations\n________________\n1.PUSH\n2.POP\n3.PEEP\n4.EXIT\nPlease Enter your Choice : "); 
	scanf("%d",&choice);
	switch(choice){
		
		case 1:
			int number;
			printf("Enter the number you want to PUSH into the STACK :");	
			scanf("%d",&number);
			push(number);			
			break;
			
		case 2:
			pop();
			break;
			
		case 3:
			peep();
			break;
				
		case 4:
			exit(1);
			break;
		
		defaut:
			printf("You have entered a wrong input!!!");
		
	}
	
	return 0;
}




void peep(){
	if(isEmpty()){
		printf("The stack is underflowing or empty !!\n");
	}
	else{
		printf("%d\n",stack[top]);
	}
	main();
}


void pop(){
	if(isEmpty()){
		printf("Your stack is underflowing !!\n PUSH some data !!\n");
	}
	else{
		stack[top] = NULL;
		top--;
	}
	main();
}

void push(int number){	
	if(top != maxSize-1){
		top ++;
		stack[top] = number;
	}
	else{
		printf("Your Stack is over flowing!!! \n POP some data!!!\n");
	}
		main();
} 



int isEmpty(){

	if(top == -1){
		return 1;
	}
	else{
		return 0;	
	}

}


