#include<stdio.h>
void  main(){
	int A[100][100],B[100][100],r,c;
	
	printf("Enter the number of rows and number of columns : ");
	scanf("%d %d",&r,&c);
	
	int i,j;
	
	printf("Enter the elements in the array : ");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			scanf("%d",&A[i][j]);		
		}
	}
	
	
	int k = 1;
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
				if(A[i][j] != 0){
					B[k][0] = i ;
					B[k][1]	= j ;
					B[k][2] = A[i][j];
					k++;
				}	
			}
		}
		
		B[0][0] = r;
		B[0][1] = c;
		B[0][2] = k-1;
		
	
	printf("\nThe Sparse Matrix Generated is :\n");
	for(i=0;i<k;i++){
		for(j=0;j<3;j++){
			printf("%d\t",B[i][j]);	
		}
		printf("\n");
	}	
		
	
}
