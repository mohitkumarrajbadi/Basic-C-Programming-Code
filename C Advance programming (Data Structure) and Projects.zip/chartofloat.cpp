#include<stdio.h>
int main(){
	float a;
	char c='a';
	a=c;
	printf("%f",a);
	return 0;
}
