#include <stdio.h>
union student
{
    char name[50];
    int roll;
};

void display(union student stu,union student stu1);
// function prototype should be below to the structure declaration otherwise compiler shows error

int main()
{
    union student stud,stud1;
    printf("Enter student's name: ");
    scanf("%s", &stud.name);
    printf("Enter roll number:");
    scanf("%d", &stud1.roll);
    display(stud,stud1);   // passing structure variable stud as argument
    return 0;
}
void display(union student stu,union student stu1){
  printf("Output\nName: %s",stu.name);
  printf("\nRoll: %d",stu1.roll);
}
