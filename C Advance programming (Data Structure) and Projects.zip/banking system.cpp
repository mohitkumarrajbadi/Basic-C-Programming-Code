#include<stdio.h>
#include<stdlib.h>

struct account{
	char name[30];
	char address[30];
	char email[30];
	long mobile;
	long aadhar;
};

void newaccount(){
	
	FILE*fptr;
	struct account a1;
	fptr=fopen("banking.txt","a+");
	printf("Enter the name of the cosumer:");
	scanf("%s",a1.name);
	printf("Enter the address of the cosumer:");
	scanf("%s",a1.address);
	printf("Enter the email of the cosumer:");
	scanf("%s",a1.email);
	printf("Enter the mobile number of the cosumer:");
	scanf("%ld",&a1.mobile);
	printf("Enter the aadhar number of the cosumer:");
	scanf("%ld",&a1.aadhar);
		
		fprintf(fptr,"%s %s %s %ld %ld",a1.name,a1.address,a1.email,a1.mobile,a1.aadhar);
		fclose(fptr);
}


int main()
{
	newaccount();
}
