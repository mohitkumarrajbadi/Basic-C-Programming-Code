#include<stdio.h>
void main()
{
	int x,y;
	printf("Enter the rows:\n");
	scanf("%d",&x);
	int matrix[x][x];
	int i,j;
	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++){
			scanf("%d",&matrix[i][j]);
		}
	}
	
	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++){
			printf("%d\t",matrix[i][j]);
		}
		printf("\n");
	}
	

	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++){
			if(i>0 && i<x-1 && j>0 && j<x-1)
			printf(" \t");
			else
			printf("%d\t",matrix[i][j]);
		}
		printf("\n");
	}
}
