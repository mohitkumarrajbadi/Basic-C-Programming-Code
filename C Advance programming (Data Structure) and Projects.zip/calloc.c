#include<stdio.h>
void main()
{
	int *ip;
	ip=(int *) calloc(2,sizeof(int));
	if(ip==NULL)
	{
		printf("Out of Memory\n");
		exit(-1);
		}	
		
		*ip=42;
		printf("ip:address %d; contents %d;\n",(int)ip,*ip);
}
