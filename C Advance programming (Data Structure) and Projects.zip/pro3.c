/*banking management system.*/
#include<stdio.h>
int newacc();
int depo(int depos);
int withd(int depos);
int bal(int depos);
int main()
{
	int ch,depos;
	char ans='Y';
	printf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");
	printf("|\tWELCOME TO \"ABK BANK LIMITED\"\t       |\n");
	printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
	while(ans=='Y'||ans=='y')
	{
		printf("---------------------------------------------------\n");
		printf("1.Create new account\t\t\t          |");
		printf("\n2.Cash deposit:\t\t\t\t          |");
		printf("\n3.Cash withdrawal:\t\t\t          |");
		printf("\n4.Check balance:\t\t\t          |\n");
		printf("----------------------------------------------------");
		printf("\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				depos=newacc();
				break;
			case 2:
				depos=depo(depos);
				printf("\n Your new balance is %d",depos);
				break;
			case 3:
				depos=withd(depos);
				printf("Your new balance after withdrawal is %d",depos);
				break;
			case 4:
				depos=bal(depos);
				printf("\n Balance is %d",depos);
				break;
		}
		printf("\nDo you want to continue(Y||N)||(y||n):");
		scanf(" %c",&ans);
	}
}
int newacc()
{
	char fname[20],lname[20],nation[50],dob[50],email[40];
	int dep;
	double num,ac;
	printf("Enter your first name:");
	scanf("%s",fname);
	printf("Enter your last name:");
	scanf("%s",lname);
	printf("Enter your nationality:");
	scanf("%s",nation);
	printf("Enter your DOB:");
	scanf("%s",dob);
	printf("Enter your phone number:");
	scanf("%lf",&num);
	printf("Enter your email id:");
	scanf("%s",email);
	printf("Enter account number:");
	scanf("%lf",&ac);
	printf("Enter your initial deposit:");
	scanf("%d",&dep);
	printf("\n\nCONGRATULATIONS!!Your Account Has Been Created Successfully");
	printf("\n\nFirst name:%s",fname);
	printf("\nLast name:%s",lname);
	printf("\nNationality:%s",nation);
	printf("\nDOB:%s",dob);
	printf("\nPhone number:%lf",num);
	printf("\nEmail id:%s",email);
	printf("\nAccount number:%lf",ac);
	printf("\nInitial deposit:%d",dep);
	return dep;
}
int depo(int depos)
{
	int dep;
	printf("Enter the amount you want to deposit:");
	scanf("%d",&dep);
	depos=depos+dep;
	return depos;
}
int withd(int depos)
{
	int with,ak;
	printf("Enter the amount you want to withdraw:");
	scanf("%d",&with);
	if(with>depos)
	{
		printf("less balance\n");
		return depos;
	}
	else
	{
		ak=depos-with;
		return ak;
	}
}
int bal(int depos)
{
	return depos;
}

