#include<stdio.h>
#include<stdlib.h>
void main()
{
	int a;
	FILE *fptr;
	fptr=fopen("rb.txt","w+");
	if(fptr==NULL){
		printf("Error!!");
		exit(1);
	}
	scanf("%d",&a);
	fprintf(fptr,"%d",a);
	//	fclose(fptr);
		
		
			
	fscanf(fptr,"%d",&a);
	printf("%d",a);
	fclose(fptr);
}
