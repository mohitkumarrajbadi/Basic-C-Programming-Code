#include<stdio.h>
#include<stdlib.h>
void main()
{
	char ch[100];
	FILE *fptr;
	fptr=fopen("first.bin","wb");
	if(fptr==NULL){
		printf("Error!!");
		exit(1);
	}
	printf("Enter the characters :");
	gets(ch);
	fwrite(&ch,sizeof(ch),1,fptr);	
	fclose(fptr);
	
	
	fptr=fopen("first.txt","rb");
	if(fptr==NULL){
		printf("Error!!");
		exit(1);
	}
	fread(&ch,sizeof(ch),1,fptr);
	printf("\n%s",ch);
	fclose(fptr);
}
