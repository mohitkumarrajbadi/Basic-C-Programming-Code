#include<stdio.h>
void main(){
	int set[10],i,positive = 0,negative = 0;
	
	printf("Enter the value into the list : ");
	
	for(i=0;i<10;i++){
	
		scanf("%d",&set[i]);
	
	}
	
	
	for(i=0;i<10;i++){
		
		if(set[i]>0){
			
			printf("\nPositive number %d  is added\n",set[i]);//You can skip this step	
			positive = positive + set[i];
		
		}
		else{
			
			printf("\nNegative number %d  is added\n",set[i]);	//You can skip this step
			negative = negative + set[i]; 
		
		}
		
	}
	
	if (positive > 999 || negative > 999)//you can give -999 here as your question not fully described
	{
		printf("\nThe sum value exceed from 999\n");//You can use exit(1) here as in your question
	}
	else{

		printf("The sum of the positive number is : %d \n",positive);
		printf("The sum of the negative number is : %d \n",negative);

	}
	
}
