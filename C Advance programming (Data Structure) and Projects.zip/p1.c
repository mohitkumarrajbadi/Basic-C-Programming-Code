#include<stdio.h>
void main()
{
	int k=1;
	printf("%d==1 is""%s\n",k,k==1?"True":"False");
}
