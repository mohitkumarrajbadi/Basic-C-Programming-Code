#include<stdio.h>
#include<string.h>

struct student{
	
	char name[20],branch[5],result[5];
	int subject[5],rollno,rank;
	int totalmark;
	
};


void bubblesort(int totalmarks[],int n){
	
	int i,j,temp;
	
	for(i=0;i<n-1;i++){
		for(j=0;j<n-i-1;j++){
			if(totalmarks[j] < totalmarks[j+1]){
				temp = totalmarks[j];
				totalmarks[j] = totalmarks[j+1];
				totalmarks[j+1] = temp;
			}
		}
	}
	
}


void main(){

	int n,i,j;
	float grandtotal = 0 , averagemarks = 0 , k = 1;
	
	printf("Enter the number of student : ");
	scanf("%d",&n);
	
	int totalmarks[n],ranking[n];
	
	struct student stud[n];
	
	//Input the student details
	for(i=0;i<n;i++){
		
		printf("Enter the name : ");
		scanf("%s",&stud[i].name);
		
		printf("Enter the rollno : ");
		scanf("%d",&stud[i].rollno);
		
		printf("Enter the branch : ");
		scanf("%s",stud[i].branch);
		
		stud[i].totalmark = 0;
		
		for(j=0;j<5;j++){
			printf("Enter the mark of the subject %d : ",j+1);
			scanf("%d",&stud[i].subject[j]);
			stud[i].totalmark += stud[i].subject[j];
		}
		
		totalmarks[i] = stud[i].totalmark;
		grandtotal += stud[i].totalmark;
		
	}
	
	averagemarks = (float) grandtotal/n;
	
		
//sorting the marks array to get the higest value
	bubblesort(totalmarks,n);	

//checking the same marks
	for(i=0;i<n;i++){
		
		if(totalmarks[i] == totalmarks[i+1]){
			for(j=0;j<n;j++){
				if(totalmarks[i] == stud[j].totalmark){
					stud[j].rank = k;
				}
			}
		}else{
			for(j=0;j<n;j++){
				if(totalmarks[i] == stud[j].totalmark){
					stud[j].rank = k;
				}
			}
			k++;
		}
	
	}	
	
	

	//Display the student details
	for(i=0;i<n;i++){
		//Giving the result value to the student
		if(stud[i].totalmark >= averagemarks){
			strcpy(stud[i].result,"PASS");
		}else{
			strcpy(stud[i].result,"FAIL");
		}
		
		if(stud[i].rank == 1){
			//Display
		printf("\nTopper student\n");	
		printf("\nStudent . %d\n",i+1);
		printf("Name : %s \n",stud[i].name);
		printf("Branch : %s \n",stud[i].branch);
		printf("Result : %s \n",stud[i].result);
		printf("Total Marks : %d \n",stud[i].totalmark);
		printf("Rank : %d \n",stud[i].rank);
		}
		
		
		if(strcmp(stud[i].result,"FAIL") == 0){
		//Display
		printf("\nFailed student\n");
		printf("\nStudent . %d\n",i+1);
		printf("Name : %s \n",stud[i].name);
		printf("Branch : %s \n",stud[i].branch);
		printf("Result : %s \n",stud[i].result);
		printf("Total Marks : %d \n",stud[i].totalmark);
		printf("Rank : %d \n",stud[i].rank);
		}
		
	}
	
}


		
	
	
	
