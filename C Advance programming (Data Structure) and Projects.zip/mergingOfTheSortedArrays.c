#include<stdio.h>

void mergingOfTheSortedArrays(int A[4],int B[5],int C[9],int m,int n){
	
	int i=0,j=0,k=0;
	
		while(i < m && j < n){
			
			if(A[i] < B[j]){
				C[k++] = A[i];
				i++;
			}
			
			else{
				C[k++] = B[j];
				j++;
			}
		
			}
			
			
			while(i < m){
				C[k++] = A[i];
				i++;	
			}
			
			
			while(j < n){
				C[k++] = B[j];
				j++;
			}
			
		
}

void main(){
	
	int A[4],B[5],C[10],m,n,i;
	
	printf("Enter the size of the array A and B : \n");
	scanf("%d %d",&m,&n);
	
	printf("Enter the %d numbers of element in the array A : \n",m);
	for(i=0;i<=(m-1);i++){
		scanf("%d",&A[i]);
	}
	
	printf("Enter the %d numbers of element in the array B : \n",n);
	for(i=0;i<=(n-1);i++){
		scanf("%d",&B[i]);
	}
	
	mergingOfTheSortedArrays(A,B,C,m,n);
	
	printf("The merged array is : \n");
	for(i=0;i<=(m+n-1);i++){
		printf("%d\n",C[i]);
	}
	
}
