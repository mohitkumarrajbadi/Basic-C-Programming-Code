#include<stdio.h>
#include<string.h>
void bubbleSort(char A[][20],int n);
main(){
	
	char A[10][20],n;
	int i,j;
	
	printf("Enter  the number of item you want in the  String : ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++){
		scanf("%s",A[i]);
	}
	
	printf("The strings before the bubble sort : \n");
	for(i=0;i<n;i++){
		printf("%s\n",A[i]);
	}
	
	bubbleSort(A,n);
	
	printf("The string after the bubble sort : \n");
	
	for(i=0;i<n;i++){
		printf("%s\n",A[i]);
	}
	
	
}

void bubbleSort(char A[][20],int n){
	
	int i,j;
	char temp[20];
	
	for(i=0;i<n-1;i++){
		for(j=0;j<n-i-1;j++){		
			if(strcmp(A[j],A[j+1])>0){
				strcpy(temp,A[j]);
				strcpy(A[j],A[j+1]);
				strcpy(A[j+1],temp);
			}
			
		}
	}
	
}
