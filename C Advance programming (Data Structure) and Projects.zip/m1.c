#include<stdio.h>
void main()
{
	int r,c;
	printf("Enter the rows:");
	scanf("%d",&r);
	printf("Enter the columns:");
	scanf("%d",&c);
	int a[r][c],b[r][c],i,j;
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			scanf("%d",&a[i][j]);
		}
	}
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			b[i][j]=" ";		
			}
		}
	
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
		if(a[i][j]==1){
			b[i][j]=a[i][j];
		}	
		}
	}
	
	printf("\n\n\n");
	for(i=0;i<r;i++){
		for(j=0;j<c;j++){
			if(b[i][j]==1)
			printf("%d\t",b[i][j]);
			else
			printf(" \t");
		}
		printf("\n");
	}
	
	
	
}
